﻿
using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using TosRC.Logger;

namespace TosRCTask.UserControl
{
    /// <summary>
    /// AudioControl.xaml 的交互逻辑
    /// </summary>
    public partial class AudioControl : System.Windows.Controls.UserControl
    {
        private string _tag = "TosRCTask.UserControl.AudioControl";
        private TimeSpan _maxTime;
        System.Windows.Threading.DispatcherTimer _timer = null;
        private string _mediaInTotalTime = "00:00";
        private string _pauseIconPath = "Images/MediaPauseIcon.xaml";
        public AudioControl()
        {
            InitializeComponent();
            LoadIcon();
           
        }

        private void LoadIcon()
        {
            try
            {
                //MediaStatueIcon.Child = TaskFlowHelp.LoadIcon(_pauseIconPath);
            }
            catch (Exception e)
            {

            } 
        }

        protected void SetAudioStyle(string styleName)
        {
            SliderPosition.Style = (Style)FindResource(styleName);
        }

        public Visibility MediaTimeVisibility
        {
            get { return LblTime.Visibility; }

            set { LblTime.Visibility = value; }
        } 
        

        public string AudioPath
        {
            get;
            private set; 

        } = string.Empty;

        public void SetAudioPath(string path)
        {
            TosRCLogger.OutputInfoLog(_tag, $"the SetAudioPath file path :{path} ");
            AudioPath = path;
        }

        public void PlayAudio()
        {
            try
            {
                var path = this.AudioPath;
                if (string.IsNullOrEmpty(path))
                {
                    path = @"Resources\TestResource\audio.mp3";
                    path = System.IO.Path.GetFullPath(path);
                }
                path = @"Resources\TestResource\audio.mp3";
                path = System.IO.Path.GetFullPath(path);
                if (File.Exists(path))
                {
                    //MySoundPlayer.LoadedBehavior = MediaState.Manual;
                    MySoundPlayer.MediaEnded += MediaElement_MediaEnded;
                    MySoundPlayer.MediaFailed += MediaElement_MediaFailed;
                    MySoundPlayer.MediaOpened += (o, e) =>
                    {
                        SliderPosition.Maximum = MySoundPlayer.NaturalDuration.TimeSpan.TotalSeconds;
                        _maxTime = MySoundPlayer.NaturalDuration.TimeSpan;
                        _mediaInTotalTime = _maxTime.Minutes.ToString().PadLeft(2, '0') + ":" + _maxTime.Seconds.ToString().PadLeft(2, '0');
                    };
                    FileInfo selectedFile = new FileInfo(path);
                    Uri uri = new Uri(selectedFile.FullName);
                    MySoundPlayer.Source = uri;
                    MySoundPlayer.Play();

                    _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
                    _timer.Tick += timer_tick;
                    _timer.Start();
                }
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputInfoLog(_tag, $"PlayAudio error :{ex} ");
            }
        }
        public void MediaPlayer_StateChange(object sender, MouseButtonEventArgs e)
        {
            MediaState mediaState = GetMediaState(MySoundPlayer);
            switch (mediaState)
            {
                case MediaState.Manual:
                case MediaState.Play:
                    MySoundPlayer.Pause();
                    break;
                case MediaState.Pause:
                case MediaState.Close:
                case MediaState.Stop:
                    MySoundPlayer.Play();
                    break;
            }
        }
        public MediaState GetMediaState(MediaElement myMedia)
        {
            FieldInfo hlp = typeof(MediaElement).GetField("_helper", BindingFlags.NonPublic | BindingFlags.Instance);
            object helperObject = hlp.GetValue(myMedia);
            FieldInfo stateField = helperObject.GetType().GetField("_currentState", BindingFlags.NonPublic | BindingFlags.Instance);
            MediaState state = (MediaState)stateField.GetValue(helperObject);
            return state;
        }
        private void timer_tick(object sender, EventArgs e)
        {
            SliderPosition.Value = MySoundPlayer.Position.TotalSeconds;
            LblTime.Text = MySoundPlayer.Position.Minutes.ToString().PadLeft(2, '0') + ":" + MySoundPlayer.Position.Seconds.ToString().PadLeft(2, '0') + "/" + _mediaInTotalTime;
        }
        private void MediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {
            ((MediaElement)sender).Position = TimeSpan.FromMilliseconds(0);
            ((MediaElement)sender).Pause();
        }

        private void MediaElement_MediaFailed(object sender, RoutedEventArgs e)
        {
            MySoundPlayer.MediaEnded -= MediaElement_MediaEnded;
            MySoundPlayer.MediaFailed -= MediaElement_MediaFailed;
            MySoundPlayer.Visibility = Visibility.Hidden;
            MySoundPlayer.Close();
        }
        public void Close_Page(object sender, RoutedEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                MySoundPlayer.Stop();
                MySoundPlayer.Source = null;
            });
        }
    }
}
