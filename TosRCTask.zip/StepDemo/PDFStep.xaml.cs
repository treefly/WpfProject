﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.WindowsRuntime;
using System.IO.MemoryMappedFiles;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using Windows.Storage;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PageDemo.xaml 的交互逻辑
    /// </summary>
    public partial class PDFStep : Page
    {
        private int _currentPageIndex; //index of pageIndexes
        private int _currentShowPanel; // current index of show panel

        /// <summary>
        /// Set the maximum number of memory streams
        /// </summary>
        private static int _maxBufferPageNum = 5;

        private static int _minBufferPageNum = 3;
        private int[] _pageIndexes = new int[_maxBufferPageNum];

        /// <summary>
        /// Set up half the maximum number of memory streams
        /// </summary>
        private int _halfBufferNum = 0;

        private double _frameHeight = 0;
        protected uint mag = 0;

        /// <summary>
        /// 拡大率（現在値）
        /// </summary>
        protected double m_CurrentZoomScale = 1;

        /// <summary>
        /// 拡大率（最大値）
        /// </summary>
        protected double m_MaxZoomScale = 1;

        private const int BORDER_WIDTH = 2;
        private Windows.Data.Pdf.PdfDocument _pdfDoc;
        private double[] _pageHeight;
        List<Image> _imageList;
        protected double BaseImageWidth = 640;

        public readonly int StepLeftOrRight = 50; // 2018/06/12 add by zhl

        private string _pdfStepPath;

        private string _tag = "TosRCTask.StepDemo.PDFStep";

        public uint PageCount { get { return _pdfDoc.PageCount; } }
        public bool _pdfScrollFocused = false;

        public PDFStep(string title,string path )
        {
            InitializeComponent();
            _pdfScrollFocused = false;
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            _pdfStepPath = path;
            TosRCLogger.OutputInfoLog(_tag, $"the pdf file path :{_pdfStepPath} ");
            OpenPdf(_pdfStepPath);
        }
        public PDFStep(JStep step)
        {
            InitializeComponent();
            _pdfScrollFocused = false;
            TaskManager.Instance.KeyDownDelegateEvent =null;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            _pdfStepPath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.PDFUrl);
            TosRCLogger.OutputInfoLog(_tag, $"the pdf file path :{_pdfStepPath} ");
            OpenPdf(_pdfStepPath);
        }

        private async void OpenPdf(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                path = System.IO.Path.GetFullPath(@"Resources\TestResource\PDF.pdf");
            }
            if (!File.Exists(path))
            {
                return;
            }
            _currentPageIndex = 0;
            _currentShowPanel = 0;
            _pageIndexes = Enumerable.Repeat(-1, _maxBufferPageNum).ToArray();
            try
            {
                string fullPath = System.IO.Path.GetFullPath(path);
                var pdfStorageFile = await StorageFile.GetFileFromPathAsync(fullPath);
                await LoadPdfDocumentAsync(pdfStorageFile);
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"OpenPdf error {ex}");
                ImagePanel.Children.Clear();
                return;
            }
            CheckPageHeight();
        }
        private void Page_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                var key = e.Key.ToString();
                switch (key)
                {
                    case "Return":
                        if (!_pdfScrollFocused)
                        {
                            PageScroll.Focus();
                        }
                        else
                        {
                            var request = new TraversalRequest(FocusNavigationDirection.Down);
                            var element = Keyboard.FocusedElement as UIElement;
                            element?.MoveFocus(request);
                        }
                        _pdfScrollFocused = !_pdfScrollFocused;
                        e.Handled = true;
                        break;
                  
                    case "Up":
                        if (_pdfScrollFocused)
                        {
                            ScrollUpOnePage();
                            e.Handled = true;
                        }
                        break;
                    case "Down":
                        if (_pdfScrollFocused)
                        {
                            ScrollDownOnePage();
                            e.Handled = true;
                        }
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            
        }
        public async Task<uint> LoadPdfDocumentAsync(Windows.Storage.StorageFile pdfFile)
        {
            _pdfDoc = await Windows.Data.Pdf.PdfDocument.LoadFromFileAsync(pdfFile);
            mag = 0;
            _pageHeight = new double[_pdfDoc.PageCount];
            _pageHeight = Enumerable.Repeat<double>(0.0, (int)_pdfDoc.PageCount).ToArray();
            return await LoadPdfDocumentFirstPageAsync();
        }
        /// <summary>
        /// Load the first page of the PDF document asynchronously.
        /// </summary>
        /// <param name="pdfFile"></param>
        /// <returns></returns>
        public async Task<uint> LoadPdfDocumentFirstPageAsync()
        {
            try
            {
                _currentPageIndex = 0;
                _currentShowPanel = 0;

                for (int i = 0; i < _maxBufferPageNum; i++)
                {
                    if (_pdfDoc.PageCount > _maxBufferPageNum)
                    {
                        _pageIndexes[i] = i - _halfBufferNum;
                    }
                    else
                    {
                        _pageIndexes[i] = i;
                    }
                }
                _imageList = new List<Image>();
                ImagePanel.Visibility = Visibility.Hidden;
                await RenderPageAsync();
                PageScroll.ScrollToTop();
                ImagePanel.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Load the first page of the PDF document asynchronously. failed {ex}");
            }
            finally
            {
                _currentPageIndex = GetCurrentPageIndex();
            }
            return this.PageCount;
        }
        private int GetCurrentPageIndex()
        {
            int indexOffset = 0;
            for (int i = 0; i < _maxBufferPageNum; i++)
            {
                if (_pageIndexes[i] >= 0) break;
                indexOffset++;
            }
            return _currentShowPanel + indexOffset;
        }
        private async Task RenderPageAsync()
        {          
            if (_pdfDoc == null || _pdfDoc.PageCount == 0)
                return;
            ImagePanel.Children.Clear();
            int counter = 0;
            for (int i = 0; i < _maxBufferPageNum; i++)
            {
                if (_pageIndexes[i] >= 0 && _pageIndexes[i] < _pdfDoc.PageCount)
                {
                    using (Windows.Storage.Streams.InMemoryRandomAccessStream bitmapStream = await RenderPageBitmapAsync((uint)_pageIndexes[i]))
                    {
                        ShowImage(bitmapStream, counter++, i);
                    }
                }
            }
        }
        private void ShowImage(Windows.Storage.Streams.InMemoryRandomAccessStream bitmapStream,int index, int indexOfPageIndexes)
        {
            try
            {           
                var memStream = bitmapStream.AsStream();
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = memStream;
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                bitmap.Freeze();

                double zoom = m_CurrentZoomScale / m_MaxZoomScale;
                Image img = new Image
                {
                    Source = bitmap,
                    Width = bitmap.PixelWidth * zoom - BORDER_WIDTH * 2
                };
                _imageList.Insert(index, img);
                Border border = new Border
                {
                    BorderThickness = new Thickness(BORDER_WIDTH),
                    BorderBrush = new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)),
                    Child = img
                };
                ImagePanel.Children.Insert(index, border);
                _pageHeight[_pageIndexes[indexOfPageIndexes]] = bitmap.Height * 0.5 * 0.9984; 
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"ShowImage failed index={index},indexOfPageIndexes={ indexOfPageIndexes } {ex}");
            }
        }

        private async Task<Windows.Storage.Streams.InMemoryRandomAccessStream> RenderPageBitmapAsync(uint index)
        {
            try
            {
                using (Windows.Data.Pdf.PdfPage pdfPage = _pdfDoc.GetPage(index))
                {
                    var options = new Windows.Data.Pdf.PdfPageRenderOptions
                    {
                        DestinationWidth = (uint) (BaseImageWidth * m_MaxZoomScale),
                        //BackgroundColor = Windows.UI.Colors.White
                    };

                    var memStream = new Windows.Storage.Streams.InMemoryRandomAccessStream();
                    await pdfPage.RenderToStreamAsync(memStream, options);

                    return memStream;
                }
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Render Page Bitmap async failed .the index is {index}.the exception is {ex}");
            }
            return null;
        }

        private void CheckPageHeight()
        {
            try
            {
                int cnt = 0;
                for (int i = 0; i < _maxBufferPageNum; i++)
                {
                    if (_pageIndexes[i] >= 0 && _pageIndexes[i] < _pdfDoc.PageCount && cnt < ImagePanel.Children.Count)
                    {
                        double height = ImagePanel.Children[cnt].RenderSize.Height;
                        if (height > 0.0)
                        {
                            _pageHeight[_pageIndexes[i]] = height / m_CurrentZoomScale;
                        }
                        cnt++;
                    }
                }
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"CheckPageHeight error {ex}");
            }
        }

        public void KeyDownHandle(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Down)
            {
                ScrollDownOnePage();
                e.Handled = true;
            }
            if (e.Key == Key.Up)
            {
                ScrollUpOnePage();
                e.Handled = true;
            }
        }
        private async void ScrollUpOnePage()
        {
           
            try
            {
                if (PageScroll.ContentVerticalOffset <= 0.0)
                {
                    if (_pdfDoc.PageCount <= _maxBufferPageNum)
                    {
                        PageScroll.ScrollToBottom();
                        return;
                    }
                    await LoadPdfDocumentLastPageAsync();
                    return;
                }
                var offset = 0.0;
                if (_currentPageIndex > _halfBufferNum)
                {
                    offset = PageScroll.ContentVerticalOffset - StepLeftOrRight;
                    _currentShowPanel = CalcNearestPanelIndex(offset);
                    _currentPageIndex = GetCurrentPageIndex();
                }
                else
                {
                    offset = await SetBufferPageAsync(StepLeftOrRight, PageScroll.ContentVerticalOffset);
                }
                PageScroll.ScrollToVerticalOffset(offset);
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Scroll move to preview page failed. The exception is  {ex}");
            }
        }

     

        public async Task<uint> LoadPdfDocumentLastPageAsync()
        {     
            try
            {
                int pageIndex = 0;
                if (_pdfDoc.PageCount > _maxBufferPageNum)
                {
                    pageIndex = (int)_pdfDoc.PageCount - _minBufferPageNum;
                }
                for (int i = 0; i < _maxBufferPageNum; i++)
                {
                    _pageIndexes[i] = pageIndex + i;
                }
                _currentPageIndex = _pageIndexes[_minBufferPageNum - 1];

                _imageList = new List<Image>();
                ImagePanel.Visibility = Visibility.Hidden;
                await RenderPageAsync();
                PageScroll.ScrollToBottom();

                _currentPageIndex = 2;
                _currentShowPanel = 2;

                ImagePanel.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Load Pdf Document Last Page Async failed. The exception is  {ex}");
            }
            return this.PageCount;
        }


        private async void ScrollDownOnePage()
        {
            try
            {
                try
                {
                    if (PageScroll.ContentVerticalOffset >= PageScroll.ScrollableHeight)
                    {
                        if (_pdfDoc.PageCount <= _maxBufferPageNum)
                        {
                            PageScroll.ScrollToVerticalOffset(0.0);
                            return;
                        }
                        else
                        {
                            bool bottomFlag = false;
                            for (int i = 0; i < _maxBufferPageNum; i++)
                            {
                                if (_pageIndexes[i] == (_pdfDoc.PageCount - 1))
                                {
                                    bottomFlag = true;
                                    break;
                                }
                            }

                            if (bottomFlag == true)
                            {
                                await LoadPdfDocumentFirstPageAsync();
                                PageScroll.ScrollToVerticalOffset(0.0);
                                return;
                            }
                        }
                    }

                    double offset = 0.0;
                    if (_currentPageIndex < _halfBufferNum)
                    {
                        offset = PageScroll.ContentVerticalOffset + StepLeftOrRight;
                        _currentShowPanel = CalcNearestPanelIndex(offset);
                        _currentPageIndex = GetCurrentPageIndex();

                    }
                    else
                    {
                        offset = await SetBufferPageAsync(-1.0 * StepLeftOrRight, PageScroll.ContentVerticalOffset);
                    }

                    PageScroll.ScrollToVerticalOffset(offset);
                }
                finally
                {
                    CheckPageHeight();
                    _currentPageIndex = GetCurrentPageIndex();
                }
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"ScrollDownOnePage error  {ex}");
            }
        }
        private int CalcNearestPanelIndex(double offset)
        {
           
            int centerIndex = -1;
            double offsetCenter = offset + _frameHeight / 2.0;
            int panelIndex = 0;
            double nearest = double.MaxValue;
            double height = 0.0;
            int panelCount = 0;
            for (int i = 0; i < _maxBufferPageNum; i++)
            {
               
                if (_pageIndexes[i] >= 0 && _pageIndexes[i] < _pdfDoc.PageCount && panelCount < ImagePanel.Children.Count)               
                {                   
                    double page_height = _pageHeight[_pageIndexes[i]] * m_CurrentZoomScale;   // zoom scale
                    double panelCenter = height + page_height / 2.0;
                    if (nearest > Math.Abs(offsetCenter - panelCenter))
                    {
                        centerIndex = panelIndex;
                        nearest = Math.Abs(offsetCenter - panelCenter);
                    }
                    height += page_height;
                    panelIndex++;
                }
            }          
            return centerIndex;
        }
        private async Task<double> SetBufferPageAsync(double delta, double offset)
        {
            return await SetBufferPage(delta, offset);
        }
        private async Task<double> SetBufferPage(double delta, double offset)
        {
            if (_pdfDoc.PageCount <= _maxBufferPageNum)
            {
                return offset - delta;
            }

            int panelNum = ImagePanel.Children.Count;
            _currentPageIndex = GetCurrentPageIndex();
            int movePage = 0;
            double scrollOffset = offset - delta;
            int nextPanelIndex = CalcNearestPanelIndex(scrollOffset);
            try
            {
                if (delta < 0)
                {
                    if (_currentShowPanel != nextPanelIndex && _pageIndexes[_maxBufferPageNum - 1] < _pdfDoc.PageCount - 1)
                    {
                       
                        movePage = await AddPdfPage(1);
                        if (nextPanelIndex > _halfBufferNum)
                        {                           
                            if (_pageIndexes[0] > 0)
                            {
                               
                                double height = _pageHeight[_pageIndexes[0] - 1] * m_CurrentZoomScale;
                                scrollOffset -= height;
                                nextPanelIndex--;
                            }
                            //nextPanelIndex--;
                        }
                    }
                }
                else if (delta > 0)
                {
                    if (_currentShowPanel != nextPanelIndex && _pageIndexes[0] > 0)
                    {
                        movePage = await AddPdfPage(-1);
                        CheckPageHeight();
                        if (_currentPageIndex >= _halfBufferNum)
                        {                            
                            double height = _pageHeight[_pageIndexes[0]] * m_CurrentZoomScale;
                            scrollOffset += height;
                            nextPanelIndex++;
                        }
                    }
                }
                _currentShowPanel = nextPanelIndex;
                _currentPageIndex = GetCurrentPageIndex();
            }
            catch (Exception ex)
            {
               
            }        
            return scrollOffset;
        }

        /// <summary>
        /// After the preloaded file is displayed, the new image is loaded
        /// </summary>
        /// <param name="addFlag"></param>
        /// <returns></returns>
        private async Task<int> AddPdfPage(int addFlag)
        {         
            int movePage = 0;
            //new  page loaded, PDF serial number updated => +1
            for (int i = 0; i < _maxBufferPageNum; i++)
            {
                _pageIndexes[i] += addFlag;
            }

            int currentPageNo = _pageIndexes[_halfBufferNum];
         
            if (currentPageNo < 0 || currentPageNo > _pdfDoc.PageCount - 1)
            {
                for (int i = 0; i < _maxBufferPageNum; i++)
                {
                    _pageIndexes[i] -= addFlag;
                }
                if (addFlag > 0 && _pageIndexes[_halfBufferNum] == _pdfDoc.PageCount - 1)
                {
                    movePage = 1;
                }
                else if (addFlag < 0 && _pageIndexes[_halfBufferNum] == 0)
                {
                    movePage = -1;
                }
                currentPageNo = _pageIndexes[_halfBufferNum];

                if (currentPageNo == 0 && movePage < 0)
                {
                    movePage = 0;
                }
                return movePage;
            }

            try
            {
                if (addFlag > 0)
                {
                    if (_pageIndexes[_maxBufferPageNum - 1] < _pdfDoc.PageCount)
                    {
                        using (Windows.Storage.Streams.InMemoryRandomAccessStream bitmapStream
                                  = await RenderPageBitmapAsync((uint)_pageIndexes[_maxBufferPageNum - 1]))
                        {
                           
                            int indexOfPageIndexes = ImagePanel.Children.Count;
                            if (_pageIndexes[0] < 0)
                            {
                                indexOfPageIndexes -= _pageIndexes[0];
                            }
                            else if (ImagePanel.Children.Count >= _maxBufferPageNum)
                            {
                                indexOfPageIndexes -= 1;
                            }
                            ShowImage(bitmapStream, ImagePanel.Children.Count, indexOfPageIndexes);
                            if (ImagePanel.Children.Count > _maxBufferPageNum)
                            {
                                _imageList.RemoveAt(0);
                                ImagePanel.Children.RemoveAt(0);
                                movePage = 0;
                            }
                            else
                            {
                                movePage = 1;
                            }
                        }
                    }
                    else
                    {
                        if (ImagePanel.Children.Count > _halfBufferNum)
                        {
                            _imageList.RemoveAt(0);
                            ImagePanel.Children.RemoveAt(0);
                            movePage = 0;
                        }
                    }
                }
                else if (addFlag < 0)
                {
                    if (_pageIndexes[0] >= 0)
                    {
                        using (Windows.Storage.Streams.InMemoryRandomAccessStream bitmapStream
                                  = await RenderPageBitmapAsync((uint)_pageIndexes[0]))
                        {
                            ShowImage(bitmapStream, 0, 0);
                            if (ImagePanel.Children.Count > _maxBufferPageNum)
                            {
                                _imageList.RemoveAt(_imageList.Count - 1);
                                ImagePanel.Children.RemoveAt(ImagePanel.Children.Count - 1);
                                movePage = 0;
                            }
                            else
                            {
                                movePage = 0;
                            }
                        }
                    }
                    else
                    {
                        if (ImagePanel.Children.Count > _halfBufferNum)
                        {
                            _imageList.RemoveAt(_imageList.Count - 1);
                            ImagePanel.Children.RemoveAt(ImagePanel.Children.Count - 1);
                            movePage = -1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
            }
            finally
            {
                _currentPageIndex = GetCurrentPageIndex();
                GC.Collect();
                GC.WaitForPendingFinalizers();  // ←これが必要
                GC.Collect();
            }
            
            return movePage;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
            ImagePanel = null;
        }
    }
}
