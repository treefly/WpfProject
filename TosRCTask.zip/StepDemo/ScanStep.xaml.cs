﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Windows.Media.Capture;
using TosRCTask.Common;
using Windows.Storage;
using TosRC.Logger;
using TosRCTask.StepDemo;
using ZXing;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// ScanStep.xaml 的交互逻辑
    /// </summary>
    public partial class ScanStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.ScanStep";
        private Storyboard m_ShowTitle;
        private Storyboard m_HiddenTitle;
        private Storyboard m_ScanLineMove;

        private const string ShowTitle = "ShowTitle";
        private const string HiddenTitle = "HiddenTitle";
        private const string ScanLineMove = "ScanLineMove";
        private bool m_StoryCamplated = true;
        private string m_ExpectValue = null;

        private DispatcherTimer timer;
        private DispatcherTimer msgtimer;
        private CameraCtrlModify m_CameraCtrl;
        private JStep step;

        private string scanValuePreview = string.Empty;

        public ScanStep()
        {
            InitializeComponent();
            m_CameraCtrl = new CameraCtrlModify();
            m_CameraCtrl.SetResolutions();
            SetPreviewImageWidth();
            SetStoryboard();
        }

        public ScanStep(JStep step)
        {
            InitializeComponent();
            m_CameraCtrl = new CameraCtrlModify();
            m_CameraCtrl.SetResolutions();
            SetPreviewImageWidth();
            SetStoryboard();
            this.step = step;
            SetTitle(step.Data.Title);
            StartScan("");
        }

        private void SetStoryboard()
        {
            m_ShowTitle = (Storyboard)this.Resources[ShowTitle];
            //m_HiddenTitle = (Storyboard)this.Resources[HiddenTitle];
            m_ScanLineMove = (Storyboard)this.Resources[ScanLineMove];
        }

        public void SetTitle(string title)
        {
            txtTitle.Text = title;

            if (string.IsNullOrEmpty(title))
            {
                if (m_StoryCamplated)
                {
                    //m_StoryCamplated = false;
                    //m_HiddenTitle?.Begin();
                }
                txtTitle.Visibility = Visibility.Hidden;
            }
            else
            {
                if (m_StoryCamplated)
                {
                    m_StoryCamplated = false;
                    m_ShowTitle?.Begin();
                }
            }
        }
        private void Storyboard_Completed(object sender, EventArgs e)
        {
            m_StoryCamplated = true;
        }

        public async void StartScan(string expectValue)
        {

            CameraCtrlModify.CamraMode mode = CameraCtrlModify.CamraMode.StillCamera;
            await m_CameraCtrl.Initialize(CameraCtrlModify.CamraMode.StillCamera, mode);
            imgScan.Source = m_CameraCtrl.GetCapturePreview();
            //imgScan.HorizontalAlignment = HorizontalAlignment.Center;
            m_CameraCtrl.CameraCtrlFailedEvent += CallBackEventProgress;
            await m_CameraCtrl.CaptureStart();
            m_ExpectValue = expectValue;

            //开启扫描
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += Timer_Tick;

            msgtimer = new DispatcherTimer();
            msgtimer.Interval = TimeSpan.FromMilliseconds(2000);
            msgtimer.Tick += Msgtimer_Tick;
            /*timer.Elapsed += (sender, er) =>
            {

               
            };*/
           
            timer.Start();
        }
        private void CallBackEventProgress(MediaCaptureFailedEventArgs errorEventArgs)
        {
            this.Dispatcher.Invoke(() =>
            {
              
            });
        }
        private void SetPreviewImageWidth()
        {
            int m_StillCameraWidth = 0;
            int m_StillCameraHeight = 0;
            m_CameraCtrl.GetCameraResolutions(CameraCtrlModify.CamraMode.StillCamera, out m_StillCameraWidth, out m_StillCameraHeight);
            if (m_StillCameraWidth == 1920 && m_StillCameraHeight == 1080)//2MP
            {
                imgScan.Width = imgScan.Height / 9 * 16;
            }
            else if (m_StillCameraWidth == 1280 && m_StillCameraHeight == 720)//0.9MP
            {
                imgScan.Width = imgScan.Height / 9 * 16;
            }
            else if (m_StillCameraWidth == 640 && m_StillCameraHeight == 480)//0.3MP
            {
                imgScan.Width = imgScan.Height / 3 * 4;
            }
            else
            {
                imgScan.Width = imgScan.Height / 9 * 16;
            }
        }
        private void Msgtimer_Tick(object sender, EventArgs e)
        {
            messageCanvas.Visibility = Visibility.Hidden;
            msgtimer.Stop();
        }

        private void ShowQRScanMessage(bool isSuccess=false)
        {
            if (isSuccess)
            {
                rightMsgText.Visibility = Visibility.Visible;
                errorMsgText.Visibility = Visibility.Hidden;
                messageCanvas.Visibility = Visibility.Visible;

            }else
            {
                rightMsgText.Visibility = Visibility.Hidden;
                errorMsgText.Visibility = Visibility.Visible;
                messageCanvas.Visibility = Visibility.Visible;
            }
            msgtimer.Tick -= Msgtimer_Tick;
            msgtimer.Tick += Msgtimer_Tick;
            msgtimer.Start();
        }


        private async void saveTempImage(BitmapSource bs)
        {

            //using(var file = File.Create(MediaCenter.TempFloder+"temp.jpg",1000,FileOptions.Asynchronous))
            //{
            //    Util.GenerateImage(bs, Util.ImageFormat.JPG, file);
            //}
        }

        private void Timer_Tick(object sender, object e)
        {
            StartScanLineMove();
            string decoded = "";
            //this.Dispatcher.BeginInvoke(new Action(delegate ()
            {
                try
                {
                    BarcodeReader Reader = new BarcodeReader();
                    BitmapSource bs = Common.Util.CaptureElementImageToBitmapSource(imgScan, (int)imgScan.ActualWidth, (int)imgScan.ActualHeight);
                    //saveTempImage(bs);
                    // MediaCenter.SaveCaptureFile(MediaCenter.TempFloder+"temp.jpg");
                    Bitmap bitmap = Common.Util.BitmapSourceToBitmap(bs);
                    Result result = Reader.Decode(bitmap);//Reader.Decode(new Bitmap(((BitmapImage)imgScan.Source).UriSource.LocalPath));
                    if (result != null)                                       // Result result = Reader.Decode(new Bitmap(((BitmapImage)imgScan.Source).UriSource.LocalPath)); ;
                        decoded = result.ToString();

                    //扫描成功
                    if (!string.IsNullOrEmpty(decoded))
                    {
                        if (decoded == m_ExpectValue)
                        {
                            //ShowQRScanMessage(true);
                            scanValue.Text = decoded;
                            scanValuePreview = decoded;
                            ReportClassControl.Instance.ScanValue = decoded;
                            m_ScanLineMove.Stop();
                            m_StoryCamplated = true;
                            //EndScan();
                        }
                        else
                        {
                            //ShowQRScanMessage(false);
                            scanValue.Text = decoded;
                            scanValuePreview = decoded;
                            ReportClassControl.Instance.ScanValue = decoded;
                            m_ScanLineMove.Stop();
                            m_StoryCamplated = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    timer.Stop();
                    timer.Start();
                }
            };//));
            //throw new NotImplementedException();
        }

        private void ScanLineMove_Completed(object sender, EventArgs e)
        {
           var scan= sender as Storyboard;
            if (m_StoryCamplated)
            {
                m_StoryCamplated = false;
                scan.Begin();
            }
            //scan.Begin();
        }

        private void StartScanLineMove()
        {
            if (m_StoryCamplated)
            {
                m_StoryCamplated = false;
                m_ScanLineMove.Begin();
            }
        }
        private void EndScanLineMove()
        {
            m_ScanLineMove.Completed -= ScanLineMove_Completed;
            m_ScanLineMove.Stop();
        }

        public void EndScan()
        {
            timer.Tick -= Timer_Tick;
            timer.Stop();
        }

        private async void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            await m_CameraCtrl.CaptureStop();
        }

       
        private void scanValue_GotFocus(object sender, RoutedEventArgs e)
        {
            scanValuePreview = scanValue.Text;
        }

        private void scanValue_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Enter:
                        int changeLength = scanValue.Text.Length - scanValuePreview.Length;
                        scanValue.Text = scanValue.Text.Substring(scanValue.CaretIndex-changeLength, changeLength);
                        scanValuePreview = scanValue.Text;
                        break;
                    case Key.Right:
                    case Key.Left:
                        scanValue.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                        break;
                    default:
                        break;
                }

            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"scanValue_PreviewKeyDown error { exception}");
            }
            e.Handled = true;
        }
    }
}
