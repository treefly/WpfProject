﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Common;
using TosRCTask.Data;

namespace TosRCTask
{
    /// <summary>
    /// PictureAudioStep.xaml 的交互逻辑
    /// </summary>
    public partial class PictureAudioStep : Page
    {
        private string _tag= "TosRCTask.PictureAudioStep";
        private string _audioPath ;
        private string _picturePath = @"Images/picture.jpg";
        private JStep step;

        #region menu_bar
        private double picBaseWidth;
        private double picBaseHeight;
        protected double baseImageWidth = 640;
        protected double baseImageHeight = 360;

        private double currentScale = 1;
        private const int m_ScrollStep = 5;
        private double MaxScale = 4;
        private double MinScale = 1;
        private System.Timers.Timer fm_timer = null;
        private double timeout_time = 3 * 1000;

        private bool function_menu_show = false;
       
        private const string ArrowLeft_xaml = "./Images/ArrowLeft_Large.xaml";

        private const string ArrowRight_xaml = "./Images/ArrowRight_Large.xaml";

        private const string Zoom_xaml = "./Images/Zoom_w.xaml";

        public bool Function_Menu_Show
        {
            set
            {
                function_menu_show = value;
                this.Function_Menu.Visibility = value == true ? Visibility.Visible : Visibility.Hidden;
            }
            get { return function_menu_show; }
        }
        #endregion

        public PictureAudioStep()
        {
            InitializeComponent();
            Register_Menu_Timer();
            LoadPicture();
            LoadMenuIcon();
            AudioMediaControl.SetAudioPath(_audioPath);
            AudioMediaControl.PlayAudio();
        }

        public PictureAudioStep(JStep step)
        {
            InitializeComponent();
            Register_Menu_Timer();
            LoadMenuIcon();
            this.step = step;
            _picturePath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.ImageUrl);
            _audioPath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.AudioUrl);
            title.Content = step.Data.Title;
            LoadPicture();
            AudioMediaControl.SetAudioPath(_audioPath);
            AudioMediaControl.PlayAudio();
        }

        private void LoadPicture()
        {
            var path = GetPicturePath();
            if (string.IsNullOrEmpty(path))
            {
                path = System.IO.Path.GetFullPath(@"Resources\TestResource\square.jpg");
            }
            path = System.IO.Path.GetFullPath(@"Resources\TestResource\square.jpg");
            if (File.Exists(path))
            {
                BitmapImage bitmap = new BitmapImage(new Uri(path));
                this.picture.Source = bitmap;
                var pic = Util.SetPictureRatio(this.picture, bitmap);
                this.picture.Height = pic.Height;
                this.picture.Width = pic.Width;
                picBaseHeight = pic.Height;
                picBaseWidth = pic.Width;
            }
        }

        private string GetPicturePath()
        {
            return System.IO.Path.GetFullPath(_picturePath) ;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
           
        }
        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            AudioMediaControl.Close_Page(null,null);
        }

        #region add Image Scale
        protected void initialize_timer()
        {
            fm_timer.Stop();
            fm_timer.Start();
        }
        private void LoadMenuIcon()
        {
            Viewbox_Zoom_A.Child = Util.LoadIcon(Zoom_xaml);
            Viewbox_ArrowLeft_A.Child = Util.LoadIcon(ArrowLeft_xaml);
            Viewbox_ArrowRight_A.Child = Util.LoadIcon(ArrowRight_xaml);
        }

        private void Register_Menu_Timer()
        {
            fm_timer = new System.Timers.Timer { Interval = timeout_time };
            fm_timer.Elapsed += Fm_Elapsed;
            fm_timer.Enabled = true;
        }

        private void Fm_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                fm_timer.Enabled = false;
                if (Function_Menu_Show == true)
                {
                    Dispatcher.Invoke(() =>
                    {
                        Function_Menu_Show = false;
                    }
                    );
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Fm_Elapsed error {exception} ");
            }
        }
        private void scrollView_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Return:
                        ShowFunction_Menu();
                        e.Handled = true;
                        break;
                    case Key.Right:
                        RightKeyHandle();
                        break;
                    case Key.Left:
                        LeftKeyHandle();
                        break;
                    case Key.Down:
                        DownKeyHandle();
                        break;
                    case Key.Up:
                        UpKeyHandle();
                        break;
                }
                e.Handled = true;
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"scrollView_KeyDown error {exception} ");
            }

        }

        private void UpKeyHandle()
        {
            try
            {
                if (Function_Menu_Show != false) return;
                ScrollMethod.Instance.LineUp(ImageView);
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"UpKeyHandle error {exception} ");
            }
        }

        private void DownKeyHandle()
        {
            if (Function_Menu_Show == false)
            {
                ScrollMethod.Instance.LineDown(ImageView);
            }
        }
        private void LeftKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale - 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineLeft(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"LeftKeyHandle error {exception} ");
            }
        }

        private void RightKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale + 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineRight(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"RightKeyHandle error {exception} ");
            }

        }

        private void ShowFunction_Menu()
        {
            Function_Menu_Show = !Function_Menu_Show;
            if (Function_Menu_Show == true)
            {
                fm_timer?.Start();
            }
        }
        protected void CalcScale(double pre_scale, double scale)
        {
            double rate = scale / pre_scale;

            this.picture.Width = picBaseWidth * scale;
            this.picture.Height = picBaseHeight * scale;

            System.Windows.Point offset = new System.Windows.Point();
            System.Windows.Point center = new System.Windows.Point();

            offset.X = ImageView.ContentHorizontalOffset;
            offset.Y = ImageView.ContentVerticalOffset;

            center.X = (offset.X + baseImageWidth / 2) * rate;
            center.Y = (offset.Y + baseImageHeight / 2) * rate;

            offset.X = center.X - baseImageWidth / 2;
            offset.Y = center.Y - baseImageHeight / 2;

            this.ImageView.ScrollToHorizontalOffset(offset.X);
            this.ImageView.ScrollToVerticalOffset(offset.Y);

            currentScale = scale;
        }

        private void scrollView_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (Function_Menu_Show == true)
            {
                initialize_timer();
            }
        }
        #endregion

        private void Button_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Enter:
                        AudioMediaControl.MediaPlayer_StateChange(null,null);
                        break;
                    case Key.Left:
                    case Key.Up:
                        AudioMediaControl.MoveFocus(new TraversalRequest(FocusNavigationDirection.Up));
                        break;
                    case Key.Right:
                    case Key.Down:
                        AudioMediaControl.MoveFocus(new TraversalRequest(FocusNavigationDirection.Down));
                        break;
                    default:
                        AudioMediaControl.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag,$"meida control click error{exception}");
            }
        }
    }
}
