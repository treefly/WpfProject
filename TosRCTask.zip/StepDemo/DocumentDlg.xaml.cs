using System.Windows.Input;
using System;
using TosRCExtendControlsLib;
using TosRC.Logger;

namespace TosRC.Settings
{
    /// <summary>
    /// Dlg.xaml の相互作用ロジック
    /// </summary>
    public partial class DocumentDlg : ExtendPage
    {
        private string tag_ = "TosRC.Settings.DocumentDlg";
        public DocumentDlg(string text)
        {
            InitializeComponent();

            DocumentText.Text = text;
        }

        public override void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // Console.WriteLine("Windows_KeyDown : Key=" + e.Key.ToString());
            switch (e.Key)
            {
                case Key.F22:
                case Key.F23:
                    ExecLineDown();
                    break;
                case Key.F21:
                case Key.F24:
                    ExecLineUp();
                    break;
                default:
                    break;
            }
        }

        public override void Window_KeyUp(object sender, KeyEventArgs e)
        {
            ExcuteVoiceCommand(e.Key);
            // Console.WriteLine("Windows_KeyUp : Key=" + e.Key.ToString());
            switch (e.Key)
            {
                case Key.Left:
                case Key.Up:
                    ExecLineUp();
                    break;
                case Key.Right:
                case Key.Down:
                    ExecLineDown();
                    break;
                case Key.Escape:
                    TosRCVLSettingListWin.HidePage(this);
                    break;
                case Key.Return:
                    break;
                default:
                    break;
            }
            return;
        }

        private void ExecLineUp(bool isMouse = false)
        {
            if (this.DocumentViewer.ContentVerticalOffset <= 0.0)
            {
                this.DocumentViewer.ScrollToBottom();
            }
            else
            {
                this.DocumentViewer.LineUp();
            }
        }

        private void ExecLineDown(bool isMouse = false)
        {
            if (this.DocumentViewer.ContentVerticalOffset >= this.DocumentViewer.ScrollableHeight)
            {
                this.DocumentViewer.ScrollToTop();
            }
            else
            {
                this.DocumentViewer.LineDown();
            }
        }

        private void ExcuteVoiceCommand(Key eKey)
        {
            System.Windows.Forms.Keys keys =(System.Windows.Forms.Keys) System.Windows.Input.KeyInterop.VirtualKeyFromKey(eKey);
            TosRCLogger.OutputInfoLog(tag_, "Voice Command method in");
            try
            {
                switch (keys)
                {
                    case System.Windows.Forms.Keys.Help:
                        TosRCVoiceCommandLib.AppVoiceCommandOperation.ShowVoiceCommandList(TosRCVoiceCommandLib.VoiceConstName.DICTIONARY_TAG_SETTING_TEXTVIEWER_HELP);
                        break;
                    case System.Windows.Forms.Keys.Prior:
                        if (this.DocumentViewer.ContentVerticalOffset <= 0.0)
                        {
                            this.DocumentViewer.ScrollToBottom();
                        }
                        else
                        {
                            this.DocumentViewer.PageUp();
                        }
                        break;
                    case System.Windows.Forms.Keys.Next:
                        if (this.DocumentViewer.ContentVerticalOffset >= this.DocumentViewer.ScrollableHeight)
                        {
                            this.DocumentViewer.ScrollToTop();
                        }
                        else
                        {
                            this.DocumentViewer.PageDown();
                        }
                        break;
                }
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(tag_, e.Message);

            }
            TosRCLogger.OutputInfoLog(tag_, "Voice Command method out");
        }
        private void ExtendPage_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            TosRC.Logger.TosRCLogger.OutputDebugLog(tag_, "Actived");
            TosRCVoiceCommandLib.AppVoiceCommandOperation.UpdateDictionary(TosRCVoiceCommandLib.VoiceConstName.DICTIONARY_TAG_SETTING_TEXTVIEWER);
        }
    }
}
