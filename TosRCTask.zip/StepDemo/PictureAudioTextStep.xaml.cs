﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Common;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PictureAudioTextStep.xaml 的交互逻辑
    /// </summary>
    public partial class PictureAudioTextStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.PictureAudioTextStep";
        private string _picturePath= @"Images/picture.jpg";
        private string _audioPath ;


        private bool _isFocusedOnDocument = false;
        private bool _canMoveDocument = false;
        #region menu_bar
        private double picBaseWidth;
        private double picBaseHeight;
        protected double baseImageWidth = 640;
        protected double baseImageHeight = 360;

        private double currentScale = 1;
        private const int m_ScrollStep = 5;
        private double MaxScale = 4;
        private double MinScale = 1;
        private System.Timers.Timer fm_timer = null;
        private double timeout_time = 3 * 1000;

        private bool function_menu_show = false;

        private const string ArrowLeft_xaml = "./Images/ArrowLeft_Large.xaml";

        private const string ArrowRight_xaml = "./Images/ArrowRight_Large.xaml";

        private const string Zoom_xaml = "./Images/Zoom_w.xaml";

        public bool Function_Menu_Show
        {
            set
            {
                function_menu_show = value;
                this.Function_Menu.Visibility = value == true ? Visibility.Visible : Visibility.Hidden;
            }
            get { return function_menu_show; }
        }
        #endregion
        public PictureAudioTextStep()
        {
            InitializeComponent();
        }

        public PictureAudioTextStep(JStep step)
        {
            InitializeComponent();
            this.title.Content = step.Data.Title;
            this._picturePath = System.IO.Path.GetFullPath(
                TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo,
                    step.Data.URLs.ImageUrl));
            this._audioPath =
                TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo,
                    step.Data.URLs.AudioUrl);
            AudioMediaControl.SetAudioPath(_audioPath);
            LoadPicture();
            LoadMenuIcon();
            Register_Menu_Timer();
            AudioMediaControl.PlayAudio();
        }

        private string GetPicturePath()
        {
            return _picturePath;
        }
        private void LoadPicture()
        {
            var path = GetPicturePath();
            if (string.IsNullOrEmpty(path))
            {
                path =@"Resources\TestResource\square.jpg";
            }
            path = @"Resources\TestResource\square.jpg";
            path = System.IO.Path.GetFullPath(path);
            if (File.Exists(path))
            {
                TosRCLogger.OutputInfoLog(_tag, $"the picture file path:{_picturePath}");
                BitmapImage bitmap = new BitmapImage(new Uri(path));
                this.image.Source = bitmap;
                var pic = Util.SetPictureRatio(this.image, bitmap);
                this.image.Height = pic.Height;
                this.image.Width = pic.Width;
                picBaseWidth = pic.Width;
                picBaseHeight = pic.Height;
            }
        }
       
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
         
        }
        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            AudioMediaControl.Close_Page(null,null);
        }

        private void AudioLabel_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp in ");
            try
            {
                var key = e.Key.ToString();
                switch (key)
                {
                    case "Return":
                        AudioMediaControl.MediaPlayer_StateChange(null, null);
                        e.Handled = true;
                        break;
                    default:
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp out ");
        }

        private void DocumentView_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                if (!_canMoveDocument && e.Key != Key.Return)
                {
                    elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    return;
                }
                switch (e.Key)
                {
                    case Key.Left:
                        ScrollMethod.Instance.PageUp(DocumentView);
                        break;
                    case Key.Right:
                        ScrollMethod.Instance.PageDown(DocumentView);
                        break;
                    case Key.Up:
                        ScrollMethod.Instance.LineUp(DocumentView);
                        break;
                    case Key.Down:
                        ScrollMethod.Instance.LineDown(DocumentView);
                        break;
                    case Key.Escape:
                        break;
                    case Key.Return:
                        if (_canMoveDocument)
                        {
                            _isFocusedOnDocument = false;
                            elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                        }
                        else
                        {
                            _isFocusedOnDocument = true;
                            _canMoveDocument = true;
                        }
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"error {exception}");
            }
            e.Handled = true;
        }

        private void DocumentView_GotFocus(object sender, RoutedEventArgs e)
        {
            _isFocusedOnDocument = true;
            _canMoveDocument = false;
        }
        #region add Image Scale
        protected void initialize_timer()
        {
            fm_timer.Stop();
            fm_timer.Start();
        }
        private void LoadMenuIcon()
        {
            Viewbox_Zoom_A.Child = Util.LoadIcon(Zoom_xaml);
            Viewbox_ArrowLeft_A.Child = Util.LoadIcon(ArrowLeft_xaml);
            Viewbox_ArrowRight_A.Child = Util.LoadIcon(ArrowRight_xaml);
        }

        private void Register_Menu_Timer()
        {
            fm_timer = new System.Timers.Timer { Interval = timeout_time };
            fm_timer.Elapsed += Fm_Elapsed;
            fm_timer.Enabled = true;
        }

        private void Fm_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                fm_timer.Enabled = false;
                if (Function_Menu_Show == true)
                {
                    Dispatcher.Invoke(() =>
                    {
                        Function_Menu_Show = false;
                    }
                    );
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Fm_Elapsed error {exception} ");
            }
        }
        private void scrollView_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Return:
                        ShowFunction_Menu();
                        e.Handled = true;
                        break;
                    case Key.Right:
                        RightKeyHandle();
                        break;
                    case Key.Left:
                        LeftKeyHandle();
                        break;
                    case Key.Down:
                        DownKeyHandle();
                        break;
                    case Key.Up:
                        UpKeyHandle();
                        break;
                }
                e.Handled = true;
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"scrollView_KeyDown error {exception} ");
            }

        }

        private void UpKeyHandle()
        {
            try
            {
                if (Function_Menu_Show != false) return;
                ScrollMethod.Instance.LineUp(ImageView);
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"UpKeyHandle error {exception} ");
            }
        }

        private void DownKeyHandle()
        {
            if (Function_Menu_Show == false)
            {
                ScrollMethod.Instance.LineDown(ImageView);
            }
        }
        private void LeftKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale - 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineLeft(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"LeftKeyHandle error {exception} ");
            }
        }

        private void RightKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale + 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineRight(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"RightKeyHandle error {exception} ");
            }

        }

        private void ShowFunction_Menu()
        {
            Function_Menu_Show = !Function_Menu_Show;
            if (Function_Menu_Show == true)
            {
                fm_timer?.Start();
            }
        }
        protected void CalcScale(double pre_scale, double scale)
        {
            double rate = scale / pre_scale;

            this.image.Width = picBaseWidth * scale;
            this.image.Height = picBaseHeight * scale;

            System.Windows.Point offset = new System.Windows.Point();
            System.Windows.Point center = new System.Windows.Point();

            offset.X = ImageView.ContentHorizontalOffset;
            offset.Y = ImageView.ContentVerticalOffset;

            center.X = (offset.X + baseImageWidth / 2) * rate;
            center.Y = (offset.Y + baseImageHeight / 2) * rate;

            offset.X = center.X - baseImageWidth / 2;
            offset.Y = center.Y - baseImageHeight / 2;

            this.ImageView.ScrollToHorizontalOffset(offset.X);
            this.ImageView.ScrollToVerticalOffset(offset.Y);

            currentScale = scale;
        }

        private void scrollView_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (Function_Menu_Show == true)
            {
                initialize_timer();
            }
        }

        public static implicit operator Window(PictureAudioTextStep v)
        {
            throw new NotImplementedException();
        }


        #endregion
    }
}
