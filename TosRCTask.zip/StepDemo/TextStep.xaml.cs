﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// TextStep.xaml 的交互逻辑
    /// </summary>
    public partial class TextStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.TextStep";
        private bool _isFocusedOnDocument=false;
        private bool _canMoveDocument = false;
        public TextStep(JStep step)
        {
            
            InitializeComponent();
            SetFocusedOnDocument();

            txtTitle.Content = step.Data.Title;
            DocumentText.Text = step.Data.Text;
            DocumentViewer.GotFocus -= DocumentGotFocused;
            DocumentViewer.GotFocus += DocumentGotFocused;
            DocumentViewer.PreviewKeyDown -= Preview_KeyDown;
            DocumentViewer.PreviewKeyDown += Preview_KeyDown;
        }
        public TextStep(string  title,string text)
        {
            InitializeComponent();
            SetFocusedOnDocument();
            txtTitle.Content = title;
            DocumentText.Text = text;
            DocumentViewer.GotFocus -= DocumentGotFocused;
            DocumentViewer.GotFocus += DocumentGotFocused;
            DocumentViewer.PreviewKeyDown -= Preview_KeyDown;
            DocumentViewer.PreviewKeyDown += Preview_KeyDown;
        }

        private void Preview_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                if (!_canMoveDocument && e.Key != Key.Return)
                {
                    elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Down));
                    return;
                }
                switch (e.Key)
                {
                    case Key.Left:
                        ScrollPageUp();
                        break;
                    case Key.Right:
                        ScrollPageDown();
                        break;
                    case Key.Up:
                        ExecLineUp();
                        break;
                    case Key.Down:
                        ExecLineDown();
                        break;
                    case Key.Escape:
                        break;
                    case Key.Return:
                        if (_canMoveDocument)
                        {
                            _isFocusedOnDocument = false;
                            elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Down));
                        }
                        else
                        {
                            _isFocusedOnDocument = true;
                            _canMoveDocument = true;
                        }
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"error {exception}");
            }
            e.Handled = true;
        }

        private void DocumentGotFocused(object sender, RoutedEventArgs e)
        {
            _isFocusedOnDocument = true;
            _canMoveDocument = false;
        }

        private void SetFocusedOnDocument()
        {
            DocumentViewer.Focus();
            _isFocusedOnDocument = false;
        }
    
        private void ScrollPageDown()
        {
            if (this.DocumentViewer.ContentVerticalOffset >= this.DocumentViewer.ScrollableHeight)
            {
                this.DocumentViewer.ScrollToTop();
            }
            else
            {
                this.DocumentViewer.PageDown();
            }
        }

        private void ScrollPageUp()
        {
            if (this.DocumentViewer.ContentVerticalOffset <= 0.0)
            {
                this.DocumentViewer.ScrollToBottom();
            }
            else
            {
                this.DocumentViewer.PageUp();
            }
        }

        private void ExecLineUp(bool isMouse = false)
        {
            if (this.DocumentViewer.ContentVerticalOffset <= 0.0)
            {
                this.DocumentViewer.ScrollToBottom();
            }
            else
            {
                this.DocumentViewer.LineUp();
            }
        }

        private void ExecLineDown(bool isMouse = false)
        {
            if (this.DocumentViewer.ContentVerticalOffset >= this.DocumentViewer.ScrollableHeight)
            {
                this.DocumentViewer.ScrollToTop();
            }
            else
            {
                this.DocumentViewer.LineDown();
            }
        }
    }
}
