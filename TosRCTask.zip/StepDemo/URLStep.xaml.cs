﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// URLStep.xaml 的交互逻辑
    /// </summary>
    public partial class URLStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.URLStep";
        private string url;
        public URLStep()
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
        }
        public URLStep(JStep step)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            SetUrl(step.Data.URLs.ShareUrl);
        }

        public void SetUrl(string url)
        {
            //url = "https://www.baidu.com/";
            if (string.IsNullOrEmpty(url))
            {
                url = "https://www.baidu.com/";
            }
            this.url = url;
            TosRCLogger.OutputInfoLog(_tag, $"the url :{url}");
            LoadWebUrl();
        }       

        private void LoadWebUrl()
        {
            try
            {                
                this.webUrl.Navigate(url);
            }
            catch (Exception)
            {
                Label messageBox = new Label
                {
                    Content = "URL  Error",
                    Foreground = Brushes.White,
                    Background = Brushes.Black,
                    FontSize = 28,
                    FontWeight = FontWeights.Medium,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                webURL.Children.Remove(webUrl);

                webURL.Children.Add(messageBox); // = MessageBox;

            }
        }
        private void Page_KeyUp(object sender, KeyEventArgs e)
        {
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp in ");
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                var key = e.Key.ToString();
                switch (key)
                {
                    case "Return":
                          break;
                    case "Right":
                        //elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Previous));
                        break;
                    case "Left":
                        //elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                        break;
                    case "Up":
                        //elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Up));
                        break;
                    case "Down":
                        //elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Down));
                        break;
                    case "Escape":
                        break;
                    default:
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp out ");
            //e.Handled = true;
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
        }
    }
}
