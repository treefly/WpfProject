﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Data;
using WMPLib;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PageDemo.xaml 的交互逻辑
    /// </summary>
    public partial class AudioStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.AudioStep";
        private string _audioStepPath  ;
        private string _audioStepTitle="title";

        private TimeSpan _maxTime;
        System.Windows.Threading.DispatcherTimer _timer = null;
        private JStep step;

        public AudioStep(string title, string mediaPath)
        {
            InitializeComponent();
            _audioStepPath = mediaPath;
            _audioStepTitle = title;
            LoadFile();
        }

        public AudioStep(JStep step)
        {
            InitializeComponent();
            _audioStepPath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.AudioUrl);
            _audioStepTitle = step.Data.Title;
            LoadFile();
            this.step = step;
        }

        /// <summary>
        /// play audio file
        /// </summary>
        private void LoadFile()
        {
            if (string.IsNullOrEmpty(_audioStepTitle))
            {
                txtTitle.Visibility = Visibility.Hidden; 
            }
            else
            {
                txtTitle.Visibility = Visibility.Visible;
                txtTitle.Content = _audioStepTitle;
            }
            AudioMediaControl.SetAudioPath(_audioStepPath);
            TosRCLogger.OutputInfoLog(_tag, $"AudioStep LoadFile ,the audio path :{_audioStepPath} ");
            AudioMediaControl.PlayAudio();
        }
        /// <summary>
        /// page close,close audio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AudioStep_OnUnloaded(object sender, RoutedEventArgs e)
        {
            AudioMediaControl.Close_Page(null,null);
        }

        private void Audiolabel_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp in ");
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                var key = e.Key.ToString();
                switch (key)
                {
                    case "Return":
                        AudioMediaControl.MediaPlayer_StateChange(null, null);
                        e.Handled = true;
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp out ");
        }
    }
   

}
