﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using TosRC.Logger;
using TosRCTask.Common;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// TextPictureStep.xaml 的交互逻辑
    /// </summary>
    public partial class TextPictureStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.TextPictureStep";
        private string _picturePath;
        private bool _isFocusedOnDocument = false;
        private bool _canMoveDocument = false;

        #region menu_bar
        private double picBaseWidth;
        private double picBaseHeight;
        protected double baseImageWidth = 640;
        protected double baseImageHeight = 360;

        private double currentScale = 1;
        private const int m_ScrollStep = 5;
        private double MaxScale = 4;
        private double MinScale = 1;
        private System.Timers.Timer fm_timer = null;
        private double timeout_time = 3 * 1000;

        private bool function_menu_show = false;

        private const string ArrowLeft_xaml = "./Images/ArrowLeft_Large.xaml";

        private const string ArrowRight_xaml = "./Images/ArrowRight_Large.xaml";

        private const string Zoom_xaml = "./Images/Zoom_w.xaml";

        public bool Function_Menu_Show
        {
            set
            {
                function_menu_show = value;
                this.Function_Menu.Visibility = value == true ? Visibility.Visible : Visibility.Hidden;
            }
            get { return function_menu_show; }
        }
        #endregion
        public TextPictureStep(string title,string text,string path)
        {
            InitializeComponent();
            this.title.Content = title;
            this._picturePath = path;
            this.DocumentText.Text = @"“……你哭个啥？”

看着眼睛红肿的颜妍，费力解开呼吸罩的陆舟，微微愣了下。

他才刚睡醒，脑子还有些晕，不记得自己哪里惹到了她。

不知道是激动还是什么，听到了这句话的她，眼眶变得更红了。

抬起胳膊抹了把眼泪，颜妍很不争气地哽咽了起来，那张往日严肃的脸再也绷不住泪水，从眼角滚落了豆大的泪珠。

“我，我还以为你醒不过来了。”

这些天来她不知道挨了多少批评，不知道挨了多少白眼，不知道在怎样的煎熬中度过。

甚至于……

就连她的亲爹，都不肯见她这个女儿。

陆舟：“……”

虽然有人这么关心自己他还是挺感动的，但总感觉这时候如果有人进来，会产生莫名其妙的误会的样子。

不确定这时候自己是不是应该体贴地安慰她两句，陆舟犹豫了一会儿，最终放弃了这个打算。

毕竟，她都这么大个人了，应该也不需要自己来安慰。

于是他便轻咳了一声，重复了一遍自己的要求。

“帮我把手机拿过来一下。”

“手，手机？”

“我的手机，别告诉我没给我充电。”陆舟试着抬了下胳膊，结果发现根本没多少力气。

看来他睡的实在是有点久了，现在全身肌肉酸软的不行。

虽然大概有人帮他做过防止肌肉萎缩的按摩，但想要一点儿后遗症都都没有还是不太可能的。

不过以他的代谢能力，彻底恢复过来大概也就两三天的事情吧，

乐观点想或许一天的时间都要不了，几个小时就够了。

当然了，在这方面，自己还是不要表现得太过惊人比较好。

对于自己的状况，陆舟还是很乐观的。

反正现在实验也成功了，他身上的担子也轻松了，在这种高干病房里呆两天也不算很坏，权当是休息了。

“我这就去给你拿。”

听到陆舟的要求之后，颜妍不敢怠慢，立刻起身，快步向旁边的柜子走去。

包括手机和随身携带的用来记录灵感的笔记本在内，陆舟身上的私人物品都放在了旁边的柜子里，没有人碰过。

在去取手机的途中，颜妍顺便将他醒来的消息报告了上级，然后重新回到了床边，将手机递了过去。

“给。”

“嗯，谢谢。”

随口道了声谢，结果手机的陆舟二话不说解除了锁屏，当发现还剩下21 % 的电，顿时松了口气。

可紧接着看到了日历，反过来的他，眼睛差点没瞪出来。

卧槽？

老子竟然睡了大半个月？！

直到这时陆舟才想起来，自己上次换过手机之后，电池的续航能力已经随着锂硫电池技术的突破达到了一个新的高度，待机半个月根本不是什么问题。

只是因为他自己有满电强迫症，平时一有机会就插着充电线，所以根本就感觉不到这其中的变化而已。

看着屏幕中的日历，陆舟心中暗暗庆幸。

这要是再升一个等级，多睡个几天，怕不是得睡到过年了。别到时候大家以为自己都凉了，连讣告都写好了……

事实上，考虑到应对各种情况，关于他变成植物人的讣告还真写好了。只不过，无论是醒过来还是醒不过来，他都不可能看到就是了。

就在这个时候，他的手机中，忽然弹出了一串围脖消息。

看着这些消息的瞬间，陆舟微微愣了下，下意识就点了进去。

然后，他就愣住了。

【点灯，大家节哀。】

【陆神！你不要走哇！（哭）（哭）】

【（蜡烛）（蜡烛）（蜡烛）】

【日常上香。】

陆舟：？？？

虽然被这么多人关心着让他很感动，但这又是点灯又是上香是什么鬼？

担心刚醒来的陆舟又被气晕过去，在旁边窥了一眼屏幕的颜妍，迅速解释了一句。

“……大家都很关心你。”

似乎觉得自己的说法似乎并不够安慰人，她紧接着又补充了一句。

“这是一种……为您祈福的方式。”

陆舟：“……你当我第一次上网吗？”

颜妍一脸尴尬，决定不再说话。

……

除了那些对他“爱得深沉”的粉丝们，还有一大堆的未接来电，短信，以及邮箱里的未读邮件。

比如，那个远在普林斯顿的小姑娘。

【教授，您在哪？】

【您生病了？！】

【我现在在上京。】

【我，我进不来……】

【我的签证时间到期了，先普林斯顿了……如果您醒来了，请一定要告诉我好吗？】

看着这封邮件，陆舟一脸复杂的表情。

沉默了一会儿，他编辑了一条邮件，发了过去。

【我没事，已经恢复了，不用担心我。】

点击了发送的按钮，陆舟叹了口气，一脸头疼地将手机丢在了床头柜上。

从来没有人如此直接地向他表达过喜欢这种感情。

老实说，虽然将这东西交给了时间去解决，但他依然不知道到底该如何处理这方面的事情。

如果……

感情这东西和数学一样简单就好了。

注意到陆舟脸上的复杂，颜妍以为他感觉哪里不舒服，于是立刻问道。

“怎么了？哪里不舒服吗？”

陆舟：“颜医生，可以问你个隐私的问题吗？”

颜妍认真地点了点头：“您问吧。”

陆舟：“你有男朋友吗？”

在听到这个问题的瞬间，颜妍的脸颊，唰的一下就红了。

男，男朋友？

没事干嘛问我有没有男朋友？

虽然她确实没有……

难道……

陷入不知所措中的颜妍，紧张地偷瞄了陆舟一眼。

虽然她从来没有考虑过和一名研究人员在一起。

但仔细一看……

似乎挺耐看的？

不，与其说是耐看，倒不如说是有点小帅气。

尤其是在认真的时候，他的身上有一种奇特的吸引力……

等等，他认真的样子我为什么会记得那么清楚？

明明窗外飘着雪花，颜妍却感觉自己的脸颊烫的，像是快要中暑了一样。

像是机器人似的，她故作冷静着，一字一顿地回答道。

“没、有。”

“是吗？”

陆舟叹了口气，表情有些失望。

“那算了。”

没有的话，问了也是白问。

果然，这种事情还是得咨询经验丰富的人。

可是问谁呢？

飞哥？罗师兄？总感觉他们经验算是丰富了，但和自己的状况又不太一样。

真是让人头大……

颜妍：“……？？？”

等等，为什么就算了？

后半句话呢？

好歹一句话说完啊！

就在她正打算追问的时候，病房的门推开了。

在一名身着军装的男人的陪同下，一位慈祥的老人出现在了门口。

看到站在门口的二位，颜妍立刻站了起来，行了个军礼。

老人笑了笑，向她点了点头，示意她不用这么严肃，甚至缓和气氛地打趣了句。

“打扰到你们了吗？”

脸颊红云还未褪去的颜妍，连忙说道：“没有，不对，没有。”

陆舟：“……？”

话说“没有”和“没有”有什么区别吗？

然而老人却像是听懂了她的支支吾吾似的，笑着摇了摇头。

“小姑娘先出去下吧，我和陆教授有事情要说。”

“……是。”

机械地点了点头，颜妍脚步僵硬地走掉了。

视线重新落在了陆舟的身上，老人停顿了片刻，神色微整，换上了郑重的表情。

“陆教授，很高兴能看到你醒来。”

“在这里，我代表祖国，代表十四亿人民，对你说声感谢！”

“你辛苦了！”";
            LoadPicture();
            LoadMenuIcon();
            Register_Menu_Timer();
        }

        public TextPictureStep(JStep step)
        {
            InitializeComponent();
            try
            {
                this.title.Content = step.Data.Title;
                this._picturePath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.ImageUrl);
                this.DocumentText.Text = step.Data.Text;
                
                LoadPicture();
                LoadMenuIcon();
                Register_Menu_Timer();
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(_tag, $"TextPictureStep init error{e}");
            }
        }

        private void LoadPicture()
        {
            try
            {
                if (string.IsNullOrEmpty(_picturePath))
                {
                    _picturePath = System.IO.Path.GetFullPath(@"Resources\TestResource\square.jpg");
                }
                _picturePath = System.IO.Path.GetFullPath(_picturePath);
                TosRCLogger.OutputInfoLog(_tag, $"the picture file path:{_picturePath}");
                BitmapImage bitmap = new BitmapImage(new Uri(_picturePath));
                this.image.Source = bitmap;
                var pic = Util.SetPictureRatio(this.image, bitmap);
                this.image.Height = pic.Height;
                this.image.Width = pic.Width;
                picBaseWidth = pic.Width;
                picBaseHeight = pic.Height;
            }
            catch (Exception e)
            {
                TosRCLogger.OutputInfoLog(_tag, $"load picture failed:{e}");
            }
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {

        }

        private void DocumentView_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                if (!_canMoveDocument && e.Key != Key.Return)
                {
                    elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    return;
                }
                switch (e.Key)
                {
                    case Key.Left:
                        ScrollMethod.Instance.PageUp(DocumentView);
                        break;
                    case Key.Right:
                        ScrollMethod.Instance.PageDown(DocumentView);
                        break;
                    case Key.Up:
                        ScrollMethod.Instance.LineUp(DocumentView);
                        break;
                    case Key.Down:
                        ScrollMethod.Instance.LineDown(DocumentView);
                        break;
                    case Key.Escape:
                        break;
                    case Key.Return:
                        if (_canMoveDocument)
                        {
                            _isFocusedOnDocument = false;
                            elementWithFocus?.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                        }
                        else
                        {
                            _isFocusedOnDocument = true;
                            _canMoveDocument = true;
                        }
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"error {exception}");
            }
            e.Handled = true;
        }

        private void DocumentView_GotFocus(object sender, RoutedEventArgs e)
        {
            _isFocusedOnDocument = true;
            _canMoveDocument = false;
        }
        #region add Image Scale
        protected void initialize_timer()
        {
            fm_timer.Stop();
            fm_timer.Start();
        }
        private void LoadMenuIcon()
        {
            Viewbox_Zoom_A.Child = Util.LoadIcon(Zoom_xaml);
            Viewbox_ArrowLeft_A.Child = Util.LoadIcon(ArrowLeft_xaml);
            Viewbox_ArrowRight_A.Child = Util.LoadIcon(ArrowRight_xaml);
        }
       
        private void Register_Menu_Timer()
        {
            fm_timer = new System.Timers.Timer { Interval = timeout_time };
            fm_timer.Elapsed += Fm_Elapsed;
            fm_timer.Enabled = true;
        }

        private void Fm_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                fm_timer.Enabled = false;
                if (Function_Menu_Show == true)
                {
                    Dispatcher.Invoke(() =>
                    {
                        Function_Menu_Show = false;
                    }
                    );
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Fm_Elapsed error {exception} ");
            }
        }
        private void scrollView_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Return:
                        ShowFunction_Menu();
                        e.Handled = true;
                        break;
                    case Key.Right:
                        RightKeyHandle();
                        break;
                    case Key.Left:
                        LeftKeyHandle();
                        break;
                    case Key.Down:
                        DownKeyHandle();
                        break;
                    case Key.Up:
                        UpKeyHandle();
                        break;
                }
                e.Handled = true;
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"scrollView_KeyDown error {exception} ");
            }

        }

        private void UpKeyHandle()
        {
            try
            {
                if (Function_Menu_Show != false) return;
                ScrollMethod.Instance.LineUp(ImageView);
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"UpKeyHandle error {exception} ");
            }
        }

        private void DownKeyHandle()
        {
            if (Function_Menu_Show == false)
            {
                ScrollMethod.Instance.LineDown(ImageView);
            }
        }
        private void LeftKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale - 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineLeft(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"LeftKeyHandle error {exception} ");
            }
        }

        private void RightKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale + 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ImageView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollMethod.Instance.LineRight(ImageView);
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"RightKeyHandle error {exception} ");
            }

        }

        private void ShowFunction_Menu()
        {
            Function_Menu_Show = !Function_Menu_Show;
            if (Function_Menu_Show == true)
            {
                fm_timer?.Start();
            }
        }
        protected void CalcScale(double pre_scale, double scale)
        {
            double rate = scale / pre_scale;

            this.image.Width = picBaseWidth * scale;
            this.image.Height = picBaseHeight * scale;

            System.Windows.Point offset = new System.Windows.Point();
            System.Windows.Point center = new System.Windows.Point();

            offset.X = ImageView.ContentHorizontalOffset;
            offset.Y = ImageView.ContentVerticalOffset;

            center.X = (offset.X + baseImageWidth / 2) * rate;
            center.Y = (offset.Y + baseImageHeight / 2) * rate;

            offset.X = center.X - baseImageWidth / 2;
            offset.Y = center.Y - baseImageHeight / 2;

            this.ImageView.ScrollToHorizontalOffset(offset.X);
            this.ImageView.ScrollToVerticalOffset(offset.Y);

            currentScale = scale;
        }

        private void scrollView_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (Function_Menu_Show == true)
            {
                initialize_timer();
            }
        }


        #endregion
    }
}
