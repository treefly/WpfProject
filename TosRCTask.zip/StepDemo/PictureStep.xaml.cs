﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Common;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PictureStep.xaml 的交互逻辑
    /// </summary>
    public partial class PictureStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.PictureStep";
        private Storyboard m_ShowTitle;
        private Storyboard m_HiddenTitle;

        private bool m_StoryCamplated = true;

        private string _mTitle = string.Empty;
        private string m_PicturePath = string.Empty;
        private JStep step;
        private double picBaseWidth;
        private double picBaseHeight;
        protected double baseImageWidth = 640;
        protected double baseImageHeight = 360;

        private double currentScale = 1;
        private const int m_ScrollStep = 5;
        private double MaxScale = 4;
        private double MinScale = 1;
        private System.Timers.Timer fm_timer = null;
        private double timeout_time=3*1000;

        private bool function_menu_show=false;

        private const string ArrowLeft_xaml = "./Images/ArrowLeft_Large.xaml";

        private const string ArrowRight_xaml = "./Images/ArrowRight_Large.xaml";

        private const string Zoom_xaml = "./Images/Zoom_w.xaml";
        public bool Function_Menu_Show {
            set
            {
                function_menu_show = value;
                this.Function_Menu.Visibility = value==true ? Visibility.Visible : Visibility.Hidden;
            }
            get { return function_menu_show; }
        }

        public PictureStep(string title,string path)
        {
            InitializeComponent();
            try
            {
                txtTitle.Content = title;
                m_PicturePath = path;
                LoadPicture(m_PicturePath);
                LoadMenuIcon();
                Register_Menu_Timer();
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(_tag, $"PictureStep init {e} ");
            }
        }


        public PictureStep(JStep step)
        {
            InitializeComponent();
            try
            {
                Register_Menu_Timer();
                txtTitle.Content = step.Data.Title;
                m_PicturePath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.ImageUrl);
                LoadPicture(m_PicturePath);
                LoadMenuIcon();
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(_tag, $"PictureStep init {e} ");
            }
        }

       
        public void SetTitle(string title)
        {
            txtTitle.Content = title;
        }
        public void LoadPicture(string filePath)
        {
            var path = System.IO.Path.GetFullPath(filePath);
            path = System.IO.Path.GetFullPath(@"Resources\TestResource\square.jpg");
            if (string.IsNullOrEmpty(path))
            {
                path = System.IO.Path.GetFullPath(@"Resources\TestResource\square.jpg");
            }
            TosRCLogger.OutputInfoLog(_tag, $"the LoadPicture file path :{path} ");

            if (File.Exists(path))
            { 
                BitmapImage bitmap = new BitmapImage(new Uri(path));
                this.ViewImage.Source = bitmap;
                var pic = Util.SetPictureRatio(this.ViewImage, bitmap);
                this.ViewImage.Height = pic.Height;
                picBaseWidth = pic.Width;
                picBaseHeight = pic.Height;
                this.ViewImage.Width = pic.Width;
            }
        }
        private void Storyboard_Completed(object sender, EventArgs e)
        {
            m_StoryCamplated = true;
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            fm_timer?.Stop();
            fm_timer?.Start();
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            fm_timer?.Close();
            fm_timer?.Dispose();
        }
        protected  void initialize_timer()
        {
            fm_timer.Stop();
            fm_timer.Start();
        }
        private void LoadMenuIcon()
        {
            Viewbox_Zoom_A.Child = ReadXaml(Zoom_xaml);
            Viewbox_ArrowLeft_A.Child = ReadXaml(ArrowLeft_xaml);
            Viewbox_ArrowRight_A.Child = ReadXaml(ArrowRight_xaml);
        }
        public UIElement ReadXaml(string iconPath)
        {
            UIElement retElement = null;
            if (System.IO.File.Exists(System.IO.Path.GetFullPath(iconPath)))
            {
                using (var sr = new StreamReader(iconPath))
                {
                    var iconStr = sr.ReadToEnd();
                    var xamlString = new StringReader(iconStr);
                    var xmlTextReader = new XmlTextReader(xamlString);
                    retElement = (UIElement)System.Windows.Markup.XamlReader.Load(xmlTextReader);
                }
            }
            else
            {
                TosRCLogger.OutputDebugLog(_tag, $"There are no Icon file. FilePath:{iconPath}");
            }
            return retElement;
        }
        private void Register_Menu_Timer()
        {
            fm_timer = new System.Timers.Timer { Interval = timeout_time };
            fm_timer.Elapsed += Fm_Elapsed;
            fm_timer.Enabled = true;
        }

        private void Fm_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                fm_timer.Enabled = false;
                if (Function_Menu_Show == true)
                {
                    Dispatcher.Invoke(() =>
                        {
                            Function_Menu_Show = false;
                        }
                    );
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Fm_Elapsed error {exception} ");
            }
        }
        private  void scrollView_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                switch (e.Key)
                {
                    case Key.Return:
                        ShowFunction_Menu();
                        e.Handled = true;
                        break;
                    case Key.Right:
                        RightKeyHandle();
                        break;
                    case Key.Left:
                        LeftKeyHandle();
                        break;
                    case Key.Down:
                        DownKeyHandle();
                        break;
                    case Key.Up:
                        UpKeyHandle();
                        break;
                }
                e.Handled = true;
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"scrollView_KeyDown error {exception} ");
            }
          
        }

        private void  UpKeyHandle()
        {
            try
            {
                if (Function_Menu_Show != false) return;
                if (this.ScrollView.ContentVerticalOffset <= 0)
                {
                    this.ScrollView.ScrollToBottom();
                }
                else
                {
                    this.ScrollView.LineUp();
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"UpKeyHandle error {exception} ");
            }
        }

        private void DownKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == false)
                {
                    if (this.ScrollView.ContentVerticalOffset >= this.ScrollView.ScrollableHeight)
                    {
                        this.ScrollView.ScrollToTop();
                    }
                    else
                    {
                        this.ScrollView.LineDown();
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"DownKeyHandle error {exception} ");
            }
        }

        private void LeftKeyHandle()
        {
            try
            {
                if (Function_Menu_Show ==true)
                {
                    double scale = (currentScale - 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ScrollView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollLeftProcess();
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"LeftKeyHandle error {exception} ");
            }
        }

        private void RightKeyHandle()
        {
            try
            {
                if (Function_Menu_Show == true)
                {
                    double scale = (currentScale + 1) % MaxScale;
                    if (scale == 0)
                    {
                        scale = MaxScale;
                    }
                    CalcScale(currentScale, scale);
                    textBlock_right_A.Text = $"x {scale}";
                }
                else
                {
                    if (currentScale == MinScale)
                    {
                        ScrollView.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    }
                    else
                    {
                        ScrollRightProcess();
                    }
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"RightKeyHandle error {exception} ");
            }
           
        }

        private void ShowFunction_Menu()
        {
            Function_Menu_Show = !Function_Menu_Show;
            if (Function_Menu_Show == true)
            {
                fm_timer?.Start();
            }
        }

        private  void ScrollRightProcess()
        {
            try
            {
                if (ScrollView.ContentHorizontalOffset >= ScrollView.ScrollableWidth)
                {
                    ScrollView.ScrollToLeftEnd();
                }
                else
                {
                    ScrollView.ScrollToHorizontalOffset(ScrollView.ContentHorizontalOffset + m_ScrollStep);
                }
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(_tag, $"ScrollRightProcess error {e} ");
            }
           
        }
        private  void ScrollLeftProcess()
        {
            try
            {
                if (ScrollView.ContentHorizontalOffset <= 0.0)
                {
                    ScrollView.ScrollToRightEnd();
                }
                else
                {
                    ScrollView.ScrollToHorizontalOffset(ScrollView.ContentHorizontalOffset - m_ScrollStep);
                }
            }
            catch (Exception e)
            {
                TosRCLogger.OutputDebugLog(_tag, $"ScrollLeftProcess error {e} ");
            }
            
        }
        protected  void CalcScale(double pre_scale, double scale)
        {
            double rate = scale / pre_scale;

            this.ViewImage.Width = picBaseWidth * scale;
            this.ViewImage.Height = picBaseHeight * scale;

            System.Windows.Point offset = new System.Windows.Point();
            System.Windows.Point center = new System.Windows.Point();

            offset.X = ScrollView.ContentHorizontalOffset;
            offset.Y = ScrollView.ContentVerticalOffset;

            center.X = (offset.X + baseImageWidth / 2) * rate;
            center.Y = (offset.Y + baseImageHeight / 2) * rate;

            offset.X = center.X - baseImageWidth / 2;
            offset.Y = center.Y - baseImageHeight / 2;

            this.ScrollView.ScrollToHorizontalOffset(offset.X);
            this.ScrollView.ScrollToVerticalOffset(offset.Y);

            currentScale = scale;
        }

        private void scrollView_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (Function_Menu_Show==true)
            {
                initialize_timer();
            }
        }
    }
}
