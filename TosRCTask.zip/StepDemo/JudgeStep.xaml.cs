﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// TextStep.xaml 的交互逻辑
    /// </summary>
    public partial class JudgeStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.JudgeStep";
        private string _defaultTitle = "Are you sure?";
        private string _defaultYesString = "Yes";
        private string _defaultNoString = "No";
        private JStep step;

        public JudgeStep()
        {
            InitializeComponent();
            btnYes.Focus();
        }

        public JudgeStep(JStep step)
        {
            InitializeComponent();
            btnYes.Focus();
            this.step = step;
            SetContent(step.Data.Title, step.Data.Condition.YesLable, step.Data.Condition.NoLable);
        }

        /// <summary>
        /// set step ui info
        /// </summary>
        /// <param name="confirmStr"></param>
        /// <param name="yesString"></param>
        /// <param name="noString"></param>
        public void SetContent(string confirmStr , string yesString,String noString)
        {
            if(string.IsNullOrEmpty(confirmStr))
            {
                confirmStr = _defaultTitle;
            }
            if (string.IsNullOrEmpty(yesString))
            {
                yesString = _defaultYesString;
            }
            if (string.IsNullOrEmpty(noString))
            {
                noString = _defaultNoString;
            }
            ConfirmText.Content = confirmStr;
            btnYes.Content = yesString;
            btnNo.Content = noString;
        }
        /// <summary>
        /// key handle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
      

        private void btnYes_Click(object sender, RoutedEventArgs e)
        {
            TaskManager.Instance.GoNextStep(btnYes.Content.ToString());
        }

        private void btnNo_Click(object sender, RoutedEventArgs e)
        {
            TaskManager.Instance.GoNextStep(btnNo.Content.ToString());
        }
    }
}
