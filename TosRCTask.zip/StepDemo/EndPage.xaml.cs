﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCTask.Data;
using TosRCTask.StepDemo;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// EndPage.xaml 的交互逻辑
    /// </summary>
    public partial class EndPage : Page
    {
        private string _tag = "TosRCTask.StepDemo.EndPage";
        public bool _isBtnCompleteShow = true;
        public bool _isBtnRestartShow = true;
        public bool _isBtnRepeatShow = true;
        public bool _isBtnResumeShow = true;

        public ReportClass _uiInfoObj;
        private JStep step;
        bool _bInit = true;

        public EndPage()
        {
            InitializeComponent();
            SetReportClassToUi();
            setButtonConfig();
        }

        public EndPage(JStep step)
        {
            InitializeComponent();
            _bInit = true;
            TaskManager.Instance.KeyDownDelegateEvent = null;
            SetReportClassToUi();
            this.step = step;
            if (step.Data?.configuration != null)
            {
                _isBtnRepeatShow = step.Data.configuration.repeat;
                _isBtnCompleteShow = step.Data.configuration.complete;
                _isBtnRestartShow = step.Data.configuration.reset;
                _isBtnResumeShow = step.Data.configuration.goback;
            }

            if (_uiInfoObj.RepeatNo== _uiInfoObj.BasicInfo.RepeatCount)
            {
                _isBtnRepeatShow = false;
            }

            setButtonConfig();
        }

        private void SetReportClassToUi()
        {
            _uiInfoObj = ReportClassControl.Instance.GetReportStatisticsObj();
            labExcuteTasks.Content = _uiInfoObj.ExecuteStepCount;
            labSkipTasks.Content = _uiInfoObj.SkipStepCount;
            labPhotos.Content = _uiInfoObj.PhotosCount;
            labVideos.Content = _uiInfoObj.VideosCount;
            labStartTime.Content = ReportClassControl.Instance.StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            labUsedTime.Content = _uiInfoObj.UsedTime;
            labRepeatCount.Content = _uiInfoObj.RepeatNo+"/"+ _uiInfoObj.BasicInfo.RepeatCount;
        }

        private void loadIcon()
        {
            try
            {
                vbxExceteTasks.Child = Common.Util.ParseImage("./Images/End_ExecutedTasks.xaml");
                vbxPhotos.Child = Common.Util.ParseImage("./Images/End_PhotosIcon.xaml");
                vbxRepeatCount.Child = Common.Util.ParseImage("./Images/End_RepeatCountIcon.xaml");
                vbxSkipTasks.Child = Common.Util.ParseImage("./Images/End_SkipCountIcon.xaml");
                vbxStartTime.Child = Common.Util.ParseImage("./Images/End_StartTime.xaml");
                vbxUsedTime.Child = Common.Util.ParseImage("./Images/End_UsedTimeIcon.xaml");
                vbxVideos.Child = Common.Util.ParseImage("./Images/End_VideoCount.xaml");
            }
            catch(Exception e)
            {

            }
        }
        private void setButtonConfig()
        {
            if (!_isBtnRepeatShow)
            {
                col3.Width = new GridLength(0, GridUnitType.Star);
                btnRepeat.Visibility = Visibility.Collapsed;
            }
            if (!_isBtnRestartShow)
            {
                col2.Width = new GridLength(0, GridUnitType.Star);
                btnRestart.Visibility = Visibility.Collapsed;

            }
            if (!_isBtnResumeShow)
            {
                col4.Width = new GridLength(0, GridUnitType.Star);
                btnResume.Visibility = Visibility.Collapsed;
            }
        }
        
        #region action
        private void completeTask()
        {
            ReportClassControl.Instance.CompleteTask();
            TaskManager.Instance.EndTask();        
        }
        private void restartTask()
        {
            TaskManager.Instance.RestartTask();
        }
        private void repeatTask()
        {
            TaskManager.Instance.RepeatTask();
        }
        private void resumeTask()
        {
            TaskManager.Instance.ResumeTask();
        }
        #endregion

        private void ShowConfirmWin()
        {
            TaskConfirmWin confirm = new TaskConfirmWin();
            confirm.ExecuteStepConfirmDelegateEventHandle -= ExecuteMethod;
            confirm.ExecuteStepConfirmDelegateEventHandle += ExecuteMethod;
            confirm.ShowDialog();
        }

        private void ExecuteMethod(bool bExc)
        {
            if (!bExc)
            {
                return;
            }
            if (btnComplete.IsFocused)
            {
                completeTask();
            }
            if (btnRepeat.IsFocused)
            {
                repeatTask();
            }
            if (btnRestart.IsFocused)
            {
                restartTask();
            }
            if (btnResume.IsFocused)
            {
                resumeTask();
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            loadIcon();
            setButtonConfig();
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
        }


        private void Page_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key==Key.Enter)
            {
                e.Handled = true;
                ShowConfirmWin();
            }
        }
    }
}
