﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml;
using Windows.Media.Capture;
using Windows.Storage;
using TosRC.Logger;
using TosRCSettingLib;
using TosRCTask.StepDemo;
using TosRCGlassLib;
using TosRCCamera;
using TosRCTask.Data;
using TosRCTask.Common;
using static TosRCTask.Common.CameraCtrlModify;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PageDemo.xaml 的交互逻辑
    /// </summary>
    public partial class RecordVideoStep : Page
    {
        CameraCtrlModify m_CameraCtrl = null;
        bool _mBInitialize = false;
        // Define event handler
        public event CameraCtrlFailedEventHandler CameraCtrlFailedEvent;
        //-----------------------------------
        //Define event handler delegate
        public delegate void CameraCtrlFailedEventHandler(MediaCaptureFailedEventArgs errorEventArgs);
        private bool _cameraDerviceIsFailed = false;

        private bool _changeColor = false;
        string _mp4Fullpath= System.AppDomain.CurrentDomain.BaseDirectory;
        string _mp4Filename;
        private string RecordVideoStepTitle;
        private string _capturePhotoIconPath = "Images/RecordIcon.xaml";
        private bool m_CameraBusy;
        private bool m_isStopped=true;
        private CriticalBatteryLevel.CriticalBatteryLevel CLevel;

        private string _tag = "RecordVideoStep";
        const int RecStopLevel = 5;  // 5 percent
        DispatcherTimer dispatcherTimer;    // Recording time management timer
        DispatcherTimer batteryCheckTimer;    // // Battery Check timer
        private int RecMaxTime = 15;   // [Minute]
        enum RecModeStatus
        {
            RecModeStatus_Non = 0,
            RecModeStatus_Init = 1,
            RecModeStatus_Rec = 2
        }
        static RecModeStatus m_RecModeStatus = RecModeStatus.RecModeStatus_Non; // Recording Mode status
        SolidColorBrush m_SolidColorNormal;     // Brush for normal background color of selected area
        SolidColorBrush m_SolidColorRec;        // Brush for background color when recording selected area
        private JStep step;

        Dictionary<string, UIElement> IconDictionary { get; set; }
        private const string DIRECTORY = @"Images";
        private const string VideoCameraModeRec_Path = DIRECTORY + "/" + @"VideoCameraModeRec.xaml";
        private const string VideoCameraMode_Path = DIRECTORY + "/" + @"RecordIcon.xaml";
        /// <summary>
        /// 
        /// </summary>
        public RecordVideoStep()
        {
            InitializeComponent();
            LoadIcon();
            
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            //LoadFile();
        }

        public RecordVideoStep(JStep step)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            this.step = step;
            RecordVideoStepTitle = step.Data.Title;
            LoadIcon();
            LoadFile();
        }

        /// <summary>
        /// 
        /// </summary>
        private void LoadIcon()
        {
            IconDictionary = new Dictionary<string, UIElement>();
            m_SolidColorNormal = new SolidColorBrush();
            m_SolidColorNormal.Color = Color.FromArgb(255, 114, 58, 231);
            m_SolidColorRec = new SolidColorBrush();
            m_SolidColorRec.Color = Color.FromArgb(255, 9, 6, 22);
            getIconByFilePath(VideoCameraModeRec_Path);
            getIconByFilePath(VideoCameraMode_Path);
            SetModeIcon();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xamlFilePath"></param>
        /// <param name="key"></param>
        private void getIconByFilePath(string xamlFilePath, string key = null)
        {
            key = key ?? xamlFilePath;

            string XamlIconFolderPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)
                                        + System.IO.Path.DirectorySeparatorChar + xamlFilePath;

            if (System.IO.File.Exists(System.IO.Path.GetFullPath(XamlIconFolderPath)))
            {
                using (var sr = new StreamReader(XamlIconFolderPath))
                {
                    var xml = XmlReader.Create(sr.BaseStream);
                    var ctr = XamlReader.Load(xml) as UIElement;

                    IconDictionary.Add(key, ctr);
                }
            }
            else
            {
                TosRCLogger.OutputDebugLog(_tag, string.Format("Error: The file {0} is not exist", xamlFilePath));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void LoadFile()
        {
            if (string.IsNullOrEmpty(RecordVideoStepTitle))
            {
                TxtTitle.Visibility = Visibility.Hidden;
            }
            else
            {
                TxtTitle.Visibility = Visibility.Visible;
                TxtTitle.Content = RecordVideoStepTitle;
            }
            LoadData();
        }
        /// <summary>
        /// 
        /// </summary>
        private async void LoadData()
        {
            try
            {
                m_CameraCtrl = new CameraCtrlModify();
                m_CameraCtrl.SetResolutions();
                SetPreviewImageWidth();
                await m_CameraCtrl.Initialize(CamraMode.StillCamera, CamraMode.VideoCamera, true);
                Preview.Source = m_CameraCtrl.GetCapturePreview();
                m_CameraCtrl.CameraCtrlFailedEvent += CallBackEventProgress;
                await m_CameraCtrl.CaptureStart();
            }
            catch (Exception excpt)
            {
                Thread.Sleep(300);
                return;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void SetPreviewImageWidth()
        {
            int m_StillCameraWidth = 0;
            int m_StillCameraHeight = 0;
            try
            {
                m_CameraCtrl.GetCameraResolutions(CameraCtrlModify.CamraMode.VideoCamera, out m_StillCameraWidth, out m_StillCameraHeight);

                if (m_StillCameraWidth == 1920 && m_StillCameraHeight == 1080)//2MP
                {
                    Preview.Width = Preview.Height / 9 * 16;

                }
                else if (m_StillCameraWidth == 1280 && m_StillCameraHeight == 720)//0.9MP
                {
                    Preview.Width = Preview.Height / 9 * 16;
                }
                else if (m_StillCameraWidth == 640 && m_StillCameraHeight == 480)//0.3MP
                {
                    Preview.Width = Preview.Height / 3 * 4;
                }
                else
                {
                    Preview.Width = Preview.Height / 9 * 16;
                }
            }
            catch (Exception e)
            {

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorEventArgs"></param>
        private void CallBackEventProgress(MediaCaptureFailedEventArgs errorEventArgs)
        {
            _cameraDerviceIsFailed = true;
            this.Dispatcher.Invoke(() =>
            {
               
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="title"></param>
        internal void SetVideoInfo(string title)
        {
            RecordVideoStepTitle = title;
            LoadFile();
        }
        /// <summary>
        /// 
        /// </summary>
        private async void SaveVideo()
        {
            // Video Mode
            if (m_CameraBusy)
            {
                return;
            }
            m_CameraBusy = true;

            StorageFile file;
            if (m_isStopped)
            {
                #region StartMovie

                if (!CanRec())
                {
                    m_CameraBusy = false;
                    return;
                }
                bool IsMicrophoneValid = AudioManager.IsMicrophoneValid();
                if (IsMicrophoneValid == false)
                {
                    return;
                }
                m_isStopped = false;
                m_RecModeStatus = RecModeStatus.RecModeStatus_Init;
                file = await CreateMoveFile();
                if (file == null)
                {
                    //can not create mp4 file 
                    return;
                }
                //change audio mode to liveRecordMode when recording video.(TIH  2018/8/31)
                SerialPortProcessor.AudioMode mode;
                SerialPortProcessor.GetAudioMode(out mode);
                if (mode == SerialPortProcessor.AudioMode.Personal)
                {
                    SerialPortProcessor.SetAudioMode(SerialPortProcessor.AudioMode.Live);
                }
              
                bool bRetry = false;
                do
                {
                    bRetry = false;
                    try
                    {
                        m_RecModeStatus = RecModeStatus.RecModeStatus_Rec;
                        await m_CameraCtrl.StartRecordToStorageFile(file, MediaCapture_RecordLimitationExceeded);

                        dispatcherTimer = new DispatcherTimer(DispatcherPriority.Normal);
                        dispatcherTimer.Interval = new TimeSpan(0, RecMaxTime, 0);
                        dispatcherTimer.Tick += Dispatcher_RecTimeOver;
                        dispatcherTimer.Start();

                        batteryCheckTimer = new DispatcherTimer(DispatcherPriority.Normal);
                        batteryCheckTimer.Interval = new TimeSpan(0, 0, 30);
                        batteryCheckTimer.Tick += Dispatcher_BatteryCheck;
                        batteryCheckTimer.Start();

                    }
                    catch (Exception err)
                    {
                        #region CatchProcess

                        TosRCLogger.OutputErrorLog(_tag, "Exception: " + err.ToString());
                        if (IsMicrophoneValid)
                        {
                            bool succrss = true;
                            try
                            {
                                TosRCLogger.OutputInfoLog(_tag, "Camera control initialization retry");
                                await m_CameraCtrl.Initialize(CamraMode.StillCamera, CamraMode.VideoCamera, true);
                                Preview.Source = m_CameraCtrl.GetCapturePreview();
                                await m_CameraCtrl.CaptureStart();
                            }
                            catch (Exception err2)
                            {
                                bRetry = false;
                                TosRCLogger.OutputErrorLog(_tag, string.Format("Failed to retry: {0}", err2.ToString()));

                                File.Delete(_mp4Fullpath);
                                TosRCLogger.OutputInfoLog(_tag, "delete mp4filename : " + _mp4Fullpath);
                        
                                m_CameraBusy = false;
                                m_isStopped = true;
                                m_RecModeStatus = RecModeStatus.RecModeStatus_Non;
                                break;
                            }
                            if (succrss)
                            {
                                bRetry = true;
                            }
                        }

                        #endregion
                    }
                } while (bRetry);

                SetModeIcon();
              

                #endregion
            }
            else
            {
                await stopRecording();
                m_RecModeStatus = RecModeStatus.RecModeStatus_Non;
                TaskManager.Instance.ExecuteVideoPreview(TosRCTask.Data.ReportClassControl.Instance.mediaFilePath
                                                         + TosRCTask.Data.ReportClassControl.Instance.resultFileName);
            }
            m_CameraBusy = false;
           
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Dispatcher_RecTimeOver(object sender, EventArgs e)
        {
            TosRCLogger.OutputWarningLog(_tag, "Dispatcher_RecTimeOver!");
            Dispatcher.Invoke(async () =>
            {
                await RecTimeOver();
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Dispatcher_BatteryCheck(object sender, EventArgs e)
        {
            await BatteryCheck();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task BatteryCheck()
        {

            if ((m_CameraBusy == true))
            {
                return;
            }
            if (CanRec(true))
                return;

            TosRCLogger.OutputInfoLog(_tag, "Stop rec due to battery level. ");

            m_CameraBusy = true;

            await stopRecording();

            m_RecModeStatus = RecModeStatus.RecModeStatus_Non;

            m_CameraBusy = false;

        }
        private async Task RecTimeOver(bool isSystemLimit = false)
        {
            await stopRecording();
        }
        private void MediaCapture_RecordLimitationExceeded(MediaCapture sender)
        {
            TosRCLogger.OutputWarningLog(_tag, "MediaCapture_RecordLimitationExceeded!");
            Dispatcher.Invoke(async () =>
            {
                await RecTimeOver(true);
            });
        }
        private async Task stopRecording()
        {
            try
            {
                dispatcherTimer.Tick -= Dispatcher_RecTimeOver;
                dispatcherTimer.Stop();

                batteryCheckTimer.Tick -= Dispatcher_BatteryCheck;
                batteryCheckTimer.Stop();

#if ViewRecTime
                RecTimer.Tick -= (ss, ee) => RecordingTime();
                RecTimer.Stop();
#endif

                await m_CameraCtrl.StopRecording(MediaCapture_RecordLimitationExceeded);
                m_isStopped = true;
                //                SelectIcon.Fill = m_SolidColorNormal;
#if ViewRecTime
                RecTimeBlock.Visibility = Visibility.Hidden;
#endif
                SetModeIcon();

                //reset audio mode to PersonalRecordMode when stop recording.(TIH  2018/8/31)
                SerialPortProcessor.AudioMode mode;
                SerialPortProcessor.GetAudioMode(out mode);
                if (mode == SerialPortProcessor.AudioMode.Live)
                {
                    SerialPortProcessor.SetAudioMode(SerialPortProcessor.AudioMode.Personal);
                }
            }
            catch (Exception)
            {
                TosRCLogger.OutputErrorLog(_tag, "Could not stop the movie.");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private void SetModeIcon()
        {
            if (!m_isStopped)
            {
                SelectIcon.Fill = m_SolidColorRec;
                SetIcon(CameraIcon, IconDictionary[VideoCameraModeRec_Path]);
            }
            else
            {
                SelectIcon.Fill = m_SolidColorNormal;
                SetIcon(CameraIcon, IconDictionary[VideoCameraMode_Path]);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="iconViewbox"></param>
        /// <param name="xamlIcon"></param>
        private void SetIcon(Viewbox iconViewbox, UIElement xamlIcon)
        {
            if (iconViewbox.Child != null)
            {
                iconViewbox.Child = null;
            }
            try
            {
                if (xamlIcon == null) return;
                var xamlIcon1 = xamlIcon as Canvas;
                iconViewbox.Child = xamlIcon1 ?? xamlIcon;
            }
            catch
            {
                // ignored
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="suppressMessageFlag"></param>
        /// <returns></returns>
        private bool CanRec(bool suppressMessageFlag = false)
        {
            bool ret = false;
            int batteryLife = 255;

            try
            {
                NativeMethods.SYSTEM_POWER_STATUS sps = new NativeMethods.SYSTEM_POWER_STATUS();
                NativeMethods.GetSystemPowerStatus(out sps);
                if (sps.BatteryFlag == 128)
                {
                    // No Sytem Battery => AC Power
                    return true;
                }
                else
                {
                    batteryLife = sps.BatteryLifePercent;
                }
            }
            catch (Exception)
            {
                batteryLife = 255;
            }
            int systemThreshold = CLevel.GetCriticalLevelForVideoRecording();
            if (systemThreshold < 0)
            {
                TosRCLogger.OutputErrorLog(_tag, "Can not record due to battery setting read error.");
                return false;
            }
            systemThreshold = (systemThreshold > 90) ? 100 : (systemThreshold + 2);
            systemThreshold = (systemThreshold > RecStopLevel) ? systemThreshold : RecStopLevel;
            if (batteryLife < 255)
            {
                if (batteryLife > systemThreshold)
                {
                    ret = true;
                    TosRCLogger.OutputInfoLog(_tag, "Can record. Battery is " + batteryLife + " percent, Battery threshold is " + systemThreshold + " percent.");
                }
                else
                {
                    ret = false;
                    if (suppressMessageFlag == true)
                    {
                        TosRCLogger.OutputErrorLog(_tag, "Can not record. Battery is " + batteryLife + " percent, Battery threshold is " + systemThreshold + " percent.");
                    }
                    else
                    {
                        //string message = TosRCCamera.Properties.Resources.TosRCCamera_009;
                        //TosRCLogger.OutputErrorLog(_tag, message);
                        //TosRCLogger.OutputErrorLog(_tag, "Battery is " + batteryLife.ToString() + " percent, Battery threshold is " + systemThreshold.ToString() + " percent.");
                        ////m_isErrorMsgShow = true;
                        //ShowMessageBox(message);
                    }
                }
            }
            else
            {
                ret = false;
                TosRCLogger.OutputErrorLog(_tag, "Could not get battery life.");
            }

            return ret;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        async Task<StorageFile> CreateMoveFile()
        {
            StorageFile file = null;
            try
            {              
                if (!Directory.Exists(_mp4Fullpath))
                {
                    Directory.CreateDirectory(_mp4Fullpath);
                }
            }
            catch (Exception)
            {               
                return null;
            }
            try
            {
                 var path=TaskCacheManager.GetProduceResourceFolderPath();
                 //var fullpaths = System.IO.Path.GetFullPath(_mp4Fullpath);
                 var myVideo = await StorageFolder.GetFolderFromPathAsync(path);
                 _mp4Filename = "TFR_" + DateTime.Now.ToString($"yyMMddHHmmssff") + ".mp4";
                 file = await myVideo.CreateFileAsync(_mp4Filename, CreationCollisionOption.GenerateUniqueName);
                //TosRCTask.Data.ReportClassControl.Instance.ResultFile(_mp4Filename);
                TosRCTask.Data.ReportClassControl.Instance.resultFileName = _mp4Filename;
                TosRCTask.Data.ReportClassControl.Instance.mediaFilePath = path;
            }
            catch (Exception)
            {
                File.Delete(_mp4Fullpath);
            }
            return file;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RecordVideoStep_OnUnloaded(object sender, RoutedEventArgs e)
        {
            StopCamera();
        }
        /// <summary>
        /// 
        /// </summary>
        private async void StopCamera()
        {
            try
            {
                TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
                await m_CameraCtrl.CaptureStop();
            }
            catch (Exception)
            {
                return;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SaveVideo();        
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            CLevel = new CriticalBatteryLevel.CriticalBatteryLevel();
            LoadData();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Page_KeyUp(object sender, KeyEventArgs e)
        {
            TosRCLogger.OutputInfoLog(_tag, $"Page_KeyUp in ");
            try
            {
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                var key = e.Key.ToString();
                switch (key)
                {
                    case "Return":
                        SaveVideo();
                        e.Handled = true;
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            //e.Handled = true;
        }
    }
}
