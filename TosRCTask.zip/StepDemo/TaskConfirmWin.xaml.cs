﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// TaskConfirmWin.xaml 的交互逻辑
    /// </summary>
    public partial class TaskConfirmWin : Window
    {
        private string _tag = "TosRCTask.StepDemo.TaskConfirmWin";

        public delegate void ExecuteStepConfirmDelegate(bool b);
        public event ExecuteStepConfirmDelegate ExecuteStepConfirmDelegateEventHandle;

        private const int WINDOW_WIDTH = 640;
        private const int WINDOW_HEIGHT = 360;
        public TaskConfirmWin()
        {
            InitializeComponent();
            this.Left = (WINDOW_WIDTH - this.Width) / 2;
            this.Top = (WINDOW_HEIGHT - this.Height) / 2;
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            var key = e.Key.ToString();
            switch (key)
            {
                case "Return":
                    ExecuteStepConfirmDelegateEventHandle?.Invoke(btnYes.IsFocused);
                    e.Handled = true;
                    this.Close();
                    break;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            btnYes.Focus();
        }

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            ExecuteStepConfirmDelegateEventHandle = null;
        }
    }
}
