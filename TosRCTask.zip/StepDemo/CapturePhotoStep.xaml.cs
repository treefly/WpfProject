﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Windows.Media.Capture;
using Windows.Media.MediaProperties;
using Windows.Storage;
using MediaCaptureWPF;
using System.IO;
using Windows.ApplicationModel.Activation;
using Windows.Media;
using TosRC.Logger;
using TosRCTask;
using TosRCTask.Common;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PageDemo.xaml 的交互逻辑
    /// </summary>
    public partial class CapturePhotoStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.CapturePhotoStep";
        CameraCtrlModify m_CameraCtrl = null;
        bool _mBInitialize = false;
        // Define event handler
        public event CameraCtrlFailedEventHandler CameraCtrlFailedEvent;
        //-----------------------------------
        //Define event handler delegate
        public delegate void CameraCtrlFailedEventHandler(MediaCaptureFailedEventArgs errorEventArgs);
        private bool CameraDerviceIsFailed = false;

        private bool ChangeColor = false;
        string CapturePhotoStepPath=System.AppDomain.CurrentDomain.BaseDirectory;
        private string CapturePhotoStepTitle="testCode";

        private string _capturePhotoIconPath = "Images/StillCamera.xaml";
        public CapturePhotoStep()
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            LoadIcon();
            LoadFile();
            LoadData();
        }

        public CapturePhotoStep(JStep step)
        {
            InitializeComponent();
            this.step = step;
            CapturePhotoStepTitle = step.Data.Title;
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += Page_KeyUp;
            TaskManager.Instance.MediaCaptureDelegateEvent = null;
            TaskManager.Instance.MediaCaptureDelegateEvent += ReTakePhoto;
            LoadIcon();
            LoadFile();
            LoadData();
        }

        private void LoadIcon()
        {
            CameraIcon.Child = Util.LoadIcon(_capturePhotoIconPath);
        }

        private void LoadFile()
        {
            //SelectIcon.Visibility = Visibility.Visible;
            //CapturePhotoStepTitle = "测试代码，注意！";
            if (string.IsNullOrEmpty(CapturePhotoStepTitle))
            {
                TxtTitle.Height = TxtTitle.Width = 0;
                MainPanel.RowDefinitions[0].Height = new GridLength(0, GridUnitType.Pixel);
                TxtTitle.Visibility = Visibility.Hidden;
            }
            else
            {
                TxtTitle.Visibility = Visibility.Visible;
                TxtTitle.Content = CapturePhotoStepTitle;
            }
        }

        internal void SetPhotoInfo(string path, string title)
        {
            CapturePhotoStepPath = path;
            CapturePhotoStepTitle = title;
            //SelectIcon.Child = TaskFlowHelp.LoadIcon(_capturePhotoIconPath);
            LoadFile();
        }

        private async void LoadData()
        {           
            try
            {
                m_CameraCtrl = new CameraCtrlModify();
                CameraCtrlModify.CamraMode mode = CameraCtrlModify.CamraMode.StillCamera;
                m_CameraCtrl.SetResolutions();
                SetPreviewImageWidth();
                await m_CameraCtrl.Initialize(CameraCtrlModify.CamraMode.StillCamera, mode);
                Preview.Source = m_CameraCtrl.GetCapturePreview();
                m_CameraCtrl.CameraCtrlFailedEvent += CallBackEventProgress;
                await m_CameraCtrl.CaptureStart();
            }
            catch (Exception excpt)
            {               
                Thread.Sleep(300);
                return;
            }
        }

        private void SetPreviewImageWidth()
        {
            int m_StillCameraWidth = 0;
            int m_StillCameraHeight = 0;
            try
            {
                m_CameraCtrl.GetCameraResolutions(CameraCtrlModify.CamraMode.StillCamera, out m_StillCameraWidth, out m_StillCameraHeight);

              
                if (m_StillCameraWidth == 1920 && m_StillCameraHeight == 1080)//2MP
                {
                    Preview.Width = Preview.Height / 9 * 16;
                }
                else if (m_StillCameraWidth == 1280 && m_StillCameraHeight == 720)//0.9MP
                {
                    Preview.Width = Preview.Height / 9 * 16;
                }
                else if (m_StillCameraWidth == 640 && m_StillCameraHeight == 480)//0.3MP
                {
                    Preview.Width = Preview.Height / 3 * 4;
                }
                else
                {
                    Preview.Width = Preview.Height / 9 * 16;
                  
                }
            }
            catch (Exception e)
            {
             
            }
        }

        private void CallBackEventProgress(MediaCaptureFailedEventArgs errorEventArgs)
        {
            CameraDerviceIsFailed = true;
            this.Dispatcher.Invoke(() =>
            {
                MessageBox.Show("Camera service is not available", "info");
            });
        }

        private BitmapImage _mStillBackupImage = null;
        private JStep step;

        private async void SavePhoto()
        {
            #region StillMode

            if (CameraDerviceIsFailed)
            {
                return;
            }
            try
            {
                StorageFile file=null;
                try
                {
                    string fileName = "TFR_" + DateTime.Now.ToString($"yyMMddHHmmssff") + ".jpg";
                    var fullpath = TaskCacheManager.GetProduceResourceFolderPath();
                    TosRCLogger.OutputInfoLog(_tag,$"the media file path :{fullpath} file name {fileName}");
                    StorageFolder myPicture = await StorageFolder.GetFolderFromPathAsync(fullpath);
                    file = await myPicture.CreateFileAsync(fileName, CreationCollisionOption.GenerateUniqueName);
                    TaskManager.Instance.ChangeRetake();
                    TosRCTask.Data.ReportClassControl.Instance.resultFileName= fileName;
                    TosRCTask.Data.ReportClassControl.Instance.mediaFilePath = fullpath;
                }
                catch (Exception ex)
                {
                    return;
                }
                try
                {
                    await m_CameraCtrl.CapturePhotoToStorageFile(file);
                }
                catch (Exception err)
                {
                    return;
                }
                try
                {
                    _mStillBackupImage = new BitmapImage();
                    if (file != null)
                    {
                        FileStream stream = File.OpenRead(file.Path);
                        _mStillBackupImage.BeginInit();
                        _mStillBackupImage.CacheOption = BitmapCacheOption.OnLoad;
                        _mStillBackupImage.StreamSource = stream;
                        _mStillBackupImage.EndInit();
                        stream.Close(); // Release files
                    }
                    CapturedPicture.Width = Preview.Width;
                    CapturedPicture.Height = Preview.Height;
                    CapturedPicture.Source = _mStillBackupImage;
                 
                    CapturedPicture.Visibility = Visibility.Visible;
                }
                catch (Exception ex)
                {
                    TosRCLogger.OutputDebugLog(_tag, $" SavePhoto error {ex}");
                    return;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"CapturePhotoStep_OnUnloaded: m_CameraCtrl.SavePhoto {exception} ");
            }
            #endregion
        }

        private void CapturePhotoStep_OnLoaded(object sender, RoutedEventArgs e)
        {
            CapturedPicture.Source = null;
            LoadData();
        }

        private async void CapturePhotoStep_OnUnloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                TaskManager.Instance.KeyDownDelegateEvent -= Page_KeyUp;
                TaskManager.Instance.MediaCaptureDelegateEvent -= ReTakePhoto;
                await m_CameraCtrl.CaptureStop();
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"CapturePhotoStep_OnUnloaded: m_CameraCtrl.CaptureStop {exception} ");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //SavePhoto();
        }
        private void Page_KeyUp(object sender, KeyEventArgs e)
        {
            TosRCLogger.OutputInfoLog(_tag, $"Page_KeyUp in ");
            try
            {
                var key = e.Key.ToString();
                UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
                switch (key)
                {
                    case "Return":
                        SavePhoto();
                        e.Handled = true;
                        break;                 
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_KeyUp {exception} ");
            }
            //TosRCLogger.OutputInfoLog(_tag, $"Page_KeyUp out ");
           
        }

        public void ReTakePhoto(object sender,KeyEventArgs e)
        {
            CapturedPicture.Source = null;
        }

    }
}
