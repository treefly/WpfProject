﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRC.Logger;
using TosRCExtendControlsLib;
using TosRCTask;
using TosRCTask.Common;
using TosRCTask.Data;
using WMPLib;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// PageDemo.xaml 的交互逻辑
    /// </summary>
    public partial class VideoStep : Page
    {
        private string _tag = " TosRCTask.StepDemo.VideoStep";
        private string _videoStepPath ;
        private TimeSpan _mediaTimeSpan ;
        System.Windows.Threading.DispatcherTimer _timer = null;
        private string _pauseIconPath = "Images/MediaPauseIcon.xaml";
        private JStep step;

        public VideoStep(string title ,string filepath)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += Window_KeyUp;
            MediaStatueIcon.Child = Util.LoadIcon(_pauseIconPath);
            _videoStepPath = filepath;
            VideoTitle.Text = title;
            LoadMedia();
        }

        public VideoStep(JStep step)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent -= Window_KeyUp;
            TaskManager.Instance.KeyDownDelegateEvent += Window_KeyUp;
            MediaStatueIcon.Child = Util.LoadIcon(_pauseIconPath);
            this.step = step;
            _videoStepPath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.VideoUrl);
            VideoTitle.Text = step.Data.Title;
            LoadMedia();
        }

        public void SetVideoInfo(string videoPath, string title)
        {
            _videoStepPath = videoPath;
            LoadMedia();
        }

        private void LoadMedia()
        {
            TosRCLogger.OutputInfoLog(_tag, $"the media file path :{_videoStepPath}");
            //_videoStepPath = System.IO.Path.GetFullPath(@"Resources\TestResource\video.mp4");
            if (string.IsNullOrEmpty(_videoStepPath))
            {
                _videoStepPath = System.IO.Path.GetFullPath(@"Resources\TestResource\video.mp4");
            }
            PlayMp4(_videoStepPath);
        }

        private void timer_tick(object sender, EventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                SliderProcess.Value = SelectedVideo.Position.TotalSeconds;
                LblTime.Content = SelectedVideo.Position.Minutes.ToString().PadLeft(2, '0') + ":" + SelectedVideo.Position.Seconds.ToString().PadLeft(2, '0') + "/" + _mediaTimeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + _mediaTimeSpan.Seconds.ToString().PadLeft(2, '0');
            });
        }
        private void  PlayMp4(string path)
        {
            if (!File.Exists(path))
            {
                return ;
            }
            SelectedVideo.MediaEnded += MediaElement_MediaEnded;
            SelectedVideo.MediaFailed += MediaElement_MediaFailed;
            try
            {
                SelectedVideo.MediaOpened += (o, e) =>
                {
                    SliderProcess.Maximum = SelectedVideo.NaturalDuration.TimeSpan.TotalSeconds;
                    _mediaTimeSpan = SelectedVideo.NaturalDuration.TimeSpan;
                    //LblTime.Content = _mediaTimeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + _mediaTimeSpan.Seconds.ToString().PadLeft(2, '0');
                };
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"OpenPdf   SelectedVideo.MediaOpened  faile ,error info  {ex}");
            }
            try
            {
                FileInfo selectedFile = new FileInfo(path);
                var uri = new Uri(selectedFile.FullName);
                SelectedVideo.Source = uri;

                var player = new WindowsMediaPlayer();
                var clip = player.newMedia(selectedFile.FullName);
                var duplication = TimeSpan.FromSeconds(clip.duration);
                if (Math.Abs(duplication.TotalSeconds) <= 0)
                {
                    return;
                }
                double vAngle = 0.0;
                int vHeight;
                int vWidth;
                if (TosRCGetMpeg4FileInfo.GetMpeg4FileInfo(selectedFile.FullName, out vAngle, out vHeight, out vWidth) == false)
                {
                    vAngle = 0.0;
                }
                var rotation = new RotateTransform(vAngle);
                SelectedVideo.LayoutTransform = rotation;
                SelectedVideo.SpeedRatio = 1.0;
                SelectedVideo.Visibility = Visibility.Visible;
                SelectedVideo.Play();

                _timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(1)
                };
                _timer.Tick += timer_tick;
                _timer.Start();
            }
            catch (Exception ex)
            {
                TosRCLogger.OutputDebugLog(_tag, $"PlayMp4  faile ,error info  {ex}");
            }
        }

        private void MediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {           
            ((MediaElement)sender).Position = TimeSpan.FromMilliseconds(0);
            ((MediaElement)sender).Pause();
        }

        private void MediaElement_MediaFailed(object sender, RoutedEventArgs e)
        {
            try
            {
                SelectedVideo.MediaEnded -= MediaElement_MediaEnded;
                SelectedVideo.MediaFailed -= MediaElement_MediaFailed;
                SelectedVideo.Visibility = Visibility.Hidden;
                SelectedVideo.Close();
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"MediaElement_MediaFailed ,error info  {exception}");
            }
           
        }
        private MediaState GetMediaState(MediaElement myMedia)
        {
            FieldInfo hlp = typeof(MediaElement).GetField("_helper", BindingFlags.NonPublic | BindingFlags.Instance);
            object helperObject = hlp.GetValue(myMedia);
            FieldInfo stateField = helperObject.GetType().GetField("_currentState", BindingFlags.NonPublic | BindingFlags.Instance);
            MediaState state = (MediaState)stateField.GetValue(helperObject);
            return state;
        }
     
        private void UIElement_OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            KeyHandle();
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                TaskManager.Instance.KeyDownDelegateEvent -= Window_KeyUp;
                SelectedVideo.Stop();
                _timer.Tick -= timer_tick;
                _timer.Stop();
                _timer = null;
                SelectedVideo = null;
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"Page_Unloaded ,error info  {exception}");
            }
          
        }

        public   void Window_KeyUp(object sender, KeyEventArgs e)
        {
            UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
            var key = e.Key.ToString();
            switch (key)
            {
                case "Return":
                    KeyHandle();
                    e.Handled = true;
                    break;
            }
            //e.Handled = true;
        }
        private void KeyHandle()
        {
            try
            {
                MediaState mediaState = GetMediaState(SelectedVideo);
                switch (mediaState)
                {
                    case MediaState.Manual:
                        SelectedVideo.Pause();
                        MediaStatueIcon.Visibility = Visibility.Visible;
                        _timer.Stop();
                        break;
                    case MediaState.Pause:
                    case MediaState.Close:
                    case MediaState.Stop:
                        SelectedVideo.Play();
                        MediaStatueIcon.Visibility = Visibility.Hidden;
                        _timer.Start();
                        break;
                    case MediaState.Play:
                        SelectedVideo.Pause();
                        _timer.Stop();
                        MediaStatueIcon.Visibility = Visibility.Visible;
                        break;
                }
            }
            catch (Exception exception)
            {
                TosRCLogger.OutputDebugLog(_tag, $"KeyHandle ,error info  {exception}");
            }
        }
    }
}
