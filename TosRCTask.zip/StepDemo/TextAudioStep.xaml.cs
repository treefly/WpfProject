﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TosRCTask;
using TosRCTask.Data;

namespace TosRCTask.StepDemo
{
    /// <summary>
    /// TextAudioStep.xaml 的交互逻辑
    /// </summary>
    public partial class TextAudioStep : Page
    {
        private string _tag = "TosRCTask.StepDemo.TextAudioStep";
        private string _audioPath;
        private string title1;
        private string mediaPath;
        private JStep step;

        public TextAudioStep(string text)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent = null;
            TaskManager.Instance.KeyDownDelegateEvent += KeyDownHandle;
        }

        public TextAudioStep(string text, string title1, string mediaPath) : this(text)
        {
            this.title1 = title1;
            this.mediaPath = mediaPath;
        }

        public TextAudioStep(JStep step)
        {
            InitializeComponent();
            TaskManager.Instance.KeyDownDelegateEvent -= KeyDownHandle;
            TaskManager.Instance.KeyDownDelegateEvent += KeyDownHandle;
            try
            {
                this.step = step;
                this.content.Text = step.Text;
                this.title.Content = step.Data.Title;
                mediaPath = TaskCacheManager.GetDependentResourceLocalPath(TaskManager.Instance.CurrentInfo, step.Data.URLs.AudioUrl);
                SetAudiPath(mediaPath);
            }
            catch (Exception e)
            {
               
            }
        }

        public void SetAudiPath(string path)
        {
            _audioPath = path;
            MediaPlayer.SetAudioPath(_audioPath);
            MediaPlayer.PlayAudio();
        }

        public void SetText(string content)
        {
             this.content.Text = content;
        }

        public void SetTitle(string title)
        {
            this.title.Content = title;
        }

        private string GetAudioPath()
        {
            return _audioPath;// Path + audioName;
        }
    
        public void KeyDownHandle(object sender, KeyEventArgs e)
        {
            UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;
            var key = e.Key.ToString();
            switch (key)
            {
                case "Return":
                    MediaPlayer.MediaPlayer_StateChange(null, null);
                    break;
                default:
                    break;
            }
            //e.Handled = true;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {
            TaskManager.Instance.KeyDownDelegateEvent -= KeyDownHandle;
            MediaPlayer.Close_Page(null,null);
        }
    }
}
